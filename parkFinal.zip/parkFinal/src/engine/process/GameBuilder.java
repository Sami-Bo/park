package engine.process;

import config.AttractionConfiguration;
import config.GameConfiguration;

import construction.Attraction;
import construction.Puerta;
import construction.Route;
import engine.map.Block;
import engine.map.Map;


/**
 * Copyright SEDAMOP - Software Engineering
 * 
 * @author tianxiao.liu@cyu.fr
 *
 */
public class GameBuilder {

	public static Map buildMap() {
		return new Map(GameConfiguration.LINE_COUNT, GameConfiguration.COLUMN_COUNT);
	}

	public static BatimentManager buildInitBatiment(Map map) {
		BatimentManager batimentManager = new BatimentManager(map);
		initializeAttractions(map,batimentManager); 
		initializePuerta(map, batimentManager);
		initializeRoute(map,batimentManager);
        initializeSalida(map, batimentManager);
        
		return batimentManager ;
	}
	
	public static MobileElementManager buildInitMElementManager(Map map, BatimentManager batimentManager) {
        MobileElementManager mobile = new MobileElementManager(map, batimentManager);
        return mobile ;
    }
	
	private static void initializeAttractions(Map map, BatimentManager manager) {
    	Block firstAttraction = map.getBlock(GameConfiguration.LINE_COUNT/2 , GameConfiguration.COLUMN_COUNT/2 + 1);
		Attraction attraction = AttractionConfiguration.RoallerCoaster;
		attraction.setBlock(firstAttraction);
    	manager.addBatiment(attraction);
    }
	
    private static void initializePuerta(Map map, BatimentManager manager) {
        Block block = map.getBlock(GameConfiguration.LINE_COUNT-1, GameConfiguration.COLUMN_COUNT / 2);
        Puerta puerta = GameFactory.createPorteEntree(block);
        puerta.setPosition(block);
    	manager.addBatiment(puerta);
    }
    
    private static void initializeSalida(Map map, BatimentManager manager) {
        Block block = map.getBlock(0, GameConfiguration.COLUMN_COUNT / 2);
        Puerta salida = GameFactory.createPorteSortie(block);
        salida.setPosition(block);
    	manager.addBatiment(salida);
    }
    
    private static void initializeRoute(Map map, BatimentManager manager) {
 	    for (int i=0;i<GameConfiguration.LINE_COUNT-2;i++) {
 	    	Block block = map.getBlock(GameConfiguration.LINE_COUNT-2-i, GameConfiguration.COLUMN_COUNT/2);
 	        Route parcelle= GameFactory.createRoad(block);
            parcelle.setBlock(block);
            manager.addBatiment(parcelle);
     	}
    }
}
