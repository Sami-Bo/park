package engine.process;

import java.util.ArrayList;

import java.util.List;

import construction.Batiment;
import engine.map.Block;
import engine.map.Map;
import engine.mobile.Employe;
import engine.mobile.Pnj;

public class BatimentManager {
	private Map map;
	
	private static List<Batiment> batiments;

	public BatimentManager(Map map) {
		this.map = map;
		batiments= new ArrayList<Batiment>();
	}

	public List<Batiment> getBatiments(){
		return batiments;
	}
	
	public Map getMap() {
		return map;
	}
	public void setMap(Map map) {
		this.map = map;
	}
	
	public void addBatiment(Batiment batiment) {
			batiments.add(batiment);	
	}
	
	public static boolean isOccupiedBlock(Block position) {
		for (Batiment batiment : batiments) {
			if (position.equals(batiment.getPosition())) {
				return true;
			}
		}
		return false;
	}
	
	public boolean estDansLaListeDeBatiment(Batiment batiment) {
		for (Batiment batiment2 : batiments) {
			if (batiment.getNom().equals(batiment2.getNom())) {
				return true;
			}
		}
		return false;
	}
	
	public static int Moyenne() {
        float  moyenne=0; 
        int nbreBatiment=0;
        int nbrEmploye=0;
        int nbrMax=0;
        float moyenne2 =0;
        int moyenneAvis=0;
        int nbrPnjs=1;
        for (Batiment batiment : batiments) {
            nbreBatiment++;
            nbrMax+= batiment.getEmployeMax();

               for (Employe employe : batiment.getListeEmploye()){
                   nbrEmploye++;
                   moyenne+= employe.getEfficacite();

                       for (Pnj pnj : batiment.getPnjs()) {
                           moyenneAvis+= pnj.getAvis();
                           nbrPnjs++;
                       }
               }
             }

        if(nbrEmploye!=0) {
            nbreBatiment--;
            moyenne= (moyenne/nbrEmploye);
            float pourcentage= nbrEmploye/nbrMax;
            moyenne2 = (moyenne *pourcentage);
            moyenneAvis= (moyenneAvis/nbrPnjs);
            moyenne2= (moyenne2 +moyenneAvis)/20;
        }

        return (int)moyenne2;
    }
	
	
}