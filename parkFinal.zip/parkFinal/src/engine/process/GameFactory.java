package engine.process;

import org.apache.log4j.Logger;

import construction.Puerta;
import construction.Route;
import engine.map.Block;
import log.LoggerUtility;

/**
 * This utility class allows the creation of routes with differents names and doors. The
 * class uses simple factory design pattern with static utility methods.
 * 
 * @author Tianxiao.Liu@u-cergy.fr
 */
public class GameFactory {
	
	/**
	 * Retrieves the logger for writing logs in
	 * 
	 * 1) a text file ("text" for the logger name) 2) or in a html file ("html" for the logger name);
	 */
	private static Logger logger = LoggerUtility.getLogger(GameFactory.class, "html");

		/**
		 * Creates a road.
		 * 
		 * @param 
		 * @return the constructed road
		 */
	public static Route createRoad(Block block) {
		logger.info("Road creation : ("+block.getColumn()+","+block.getLine()+")" );
		int tailleRoute[] = {1,1};
		String nom = "route" +block.getColumn()+block.getLine();
		return new Route("ROUTE", tailleRoute, 10, 0,  30, nom, 10);
	}
	
	public static Puerta createPorteEntree(Block block) {
		logger.info("Door creation : ("+block.getColumn()+","+block.getLine()+")" );
		return new Puerta("PORTEENTREE", null,0,0,0,"porte",0);
	}
	
	public static Puerta createPorteSortie(Block block) {
		logger.info("Door creation : ("+block.getColumn()+","+block.getLine()+")" );
		
		logger.trace("Door creation : ("+block.getColumn()+","+block.getLine()+")" );
		logger.debug("Door creation : ("+block.getColumn()+","+block.getLine()+")" );
		logger.info("Door creation : ("+block.getColumn()+","+block.getLine()+")" );
		logger.warn("Door creation : ("+block.getColumn()+","+block.getLine()+")" );
		logger.error("Door creation : ("+block.getColumn()+","+block.getLine()+")" );
		logger.fatal("Door creation : ("+block.getColumn()+","+block.getLine()+")" );

		return new Puerta("PORTESORTIE", null,0,0,0,"porte",0);
	}
}
