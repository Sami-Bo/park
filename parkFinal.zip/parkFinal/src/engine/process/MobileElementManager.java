package engine.process;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import construction.Magasin;
import construction.Attraction;
import construction.Batiment;
import construction.Puerta;
import construction.Route;
import engine.map.Block;
import engine.map.Map;
import engine.mobile.Employe;
import engine.mobile.Niveau;
import engine.mobile.Pnj;
import engine.mobile.Satisfaction;
import engine.mobile.Tirelire;
import gui.CalendrierGUI;
import gui.MenuInformationRessources;

import java.lang.Math;


/**
 * Copyright SEDAMOP - Software Engineering
 * 
 * @author tianxiao.liu@cyu.fr
 *
 */
public class MobileElementManager {
	private Map map;

	private List<Batiment> batiments;
	private List<Batiment> batimentsSurcharges;
	
	private List<Pnj> visiteurs;
	
	private BatimentManager batimentManager;
	
	private int round = 0;

	public MobileElementManager(Map map, BatimentManager batimentManager) {
		this.map = map;
		this.batimentManager = batimentManager;
		
		batiments = batimentManager.getBatiments();
		batimentsSurcharges = new ArrayList<Batiment>();
		visiteurs = new CopyOnWriteArrayList<Pnj>();
	}
	
	public void add(Pnj pnj) {
		visiteurs.add(pnj);
	}
	
	public void generatePnJ() {
		Puerta puerta = getPorteEntree();
		Block position = puerta.getPosition();
		
		Pnj pnj = new Pnj(Pnj.getRandomNumber(),position);
		giveRandomBatimentExceptPorteEntreeEtDecoEtRoute(pnj);
		CalculItineraire(pnj);
		double i = Pnj.getRandomNumber() - (Satisfaction.getTaux()/5);
		if (i<12 && !CalculItineraire(pnj)) {
			add(pnj);
			Tirelire.getInstance().calculArgent(Tirelire.getPrixEntree());
	        Tirelire.updateVariationTirelire(Tirelire.getPrixEntree());
			MenuInformationRessources.getInstance().setArgent();
		}
	}
	private void movePnjs() {

		List<Pnj> pnjs = new ArrayList<Pnj>();

		for (Pnj pnj : visiteurs) {
			//si le pnj n'est pas arrive a son attraction
			if (pnj.getPosition().getLine()!= pnj.getBatiment().getPosition().getLine() || pnj.getPosition().getColumn()!= pnj.getBatiment().getPosition().getColumn()) {
				if (pnj.getItineraire().size()!=0) {
					Block newPosition = pnj.getItineraire().get(0);
					List<Block> blocks = new ArrayList<Block>();
					for (int i =1; i<pnj.getItineraire().size();i++) {
						blocks.add(pnj.getItineraire().get(i));
					}
					pnj.setItineraire(blocks);
					pnj.setPosition(newPosition);
				}
				else {
					pnjs.add(pnj);
				}
			}
			else if(isBatiment(pnj.getPosition())) 
			{
				if(isMagasin(pnj.getPosition()))
				{
					Magasin m = getMagasin(pnj.getPosition());
						if(m.getPnjs().size()<m.getCapaciteMax()) 
						{
							m.setPnj(pnj);
							int HasardAchat=(int) (Math.random()*100);
							for(int index=0; index<3 ; index++) {
								if(m.getArticleCible(index).getChanceAchat()>=HasardAchat) {
									Tirelire.getInstance().calculArgent(m.getArticleCible(index).getPrix());
								}
							}
						}
						else 
						{
							if (!batimentsSurcharges.contains(m)) 
							{
								batimentsSurcharges.add(m);
								Satisfaction.DowngradeSatisfaction();
		                        Satisfaction.updateVariationSatisfaction(-1);
							}
						}
						pnjs.add(pnj);
				}
				else {
					Batiment b = getBatiment(pnj.getPosition());
					if (!b.equals(getPorteSortie())) 
					{
						if(b.getPnjs().size()<b.getCapaciteMax())
							b.setPnj(pnj);
						else 
						{
							if (!batimentsSurcharges.contains(b))
							{
                            batimentsSurcharges.add(b);
                        	Satisfaction.DowngradeSatisfaction();
                        	Satisfaction.updateVariationSatisfaction(-1);
							}
						}
					}
					pnjs.add(pnj);
				} 
			}
			else 
			{
				pnjs.add(pnj);
			}
		
		}
		for (Pnj pnja : pnjs) {
			visiteurs.remove(pnja);
		}
		

	}

	public void giveRandomBatimentExceptPorteEntreeEtDecoEtRoute(Pnj pnj) {
		List<Attraction> attractions = getAttractions();
		List<Magasin> magasins = getMagasins();
		Puerta puerta = getPorteSortie();
		
		List<Batiment> batimentsAMP = new ArrayList<Batiment>();
		for (Attraction a : attractions) {
			batimentsAMP.add(a);
		}
		for (Magasin m : magasins) {
			batimentsAMP.add(m);
		}
		batimentsAMP.add(puerta);
		
		int indiceHasard = (int) (Math.random() * (batimentsAMP.size()));
		pnj.setBatiment(batimentsAMP.get(indiceHasard));
	}
	
	public boolean CalculItineraire(Pnj pnj) {
		List<Route> routes = new ArrayList<Route>();
		routes = getRoutes();
		
		List<Block> fausseRoute= new ArrayList<Block>();
		List<Block> routesPossible = new ArrayList<Block>();

		List<Block> routesBanniesAToutJamais = new ArrayList<Block>();
		List<Block> routesBanniesTemporairement = new ArrayList<Block>();
		
		Block batimentPosition = pnj.getBatiment().getPosition();
		Block currentPosition = pnj.getPosition();
		
		boolean erreur = false;
								
		while (currentPosition.getColumn() != batimentPosition.getColumn() || currentPosition.getLine() != batimentPosition.getLine())
		{
			
			routesBanniesTemporairement.add(currentPosition);
			
			Block bDroite = new Block(-10,-10);
			Block bHaut = new Block(-10,-10);
			Block bGauche = new Block(-10,-10);
			Block bBas = new Block(-10,-10);
						
			if (currentPosition.getColumn()+1<map.getColumnCount())
				bDroite = map.getBlock(currentPosition.getLine(), currentPosition.getColumn()+1);
			if (currentPosition.getLine()-1>=0)
				bHaut = map.getBlock(currentPosition.getLine()-1, currentPosition.getColumn());
			if (currentPosition.getColumn()-1>=0)
				bGauche = map.getBlock(currentPosition.getLine(), currentPosition.getColumn()-1);
			if (currentPosition.getLine()+1<map.getLineCount())
				bBas = map.getBlock(currentPosition.getLine()+1, currentPosition.getColumn());
			
			for (int i=0; i<routes.size(); i++) {
				if ((routes.get(i).getPosition().getColumn() == bDroite.getColumn() && routes.get(i).getPosition().getLine() == bDroite.getLine()) || (batimentPosition.getColumn() == bDroite.getColumn() && batimentPosition.getLine() == bDroite.getLine())) {
					if (!banTemp(bDroite, routesBanniesTemporairement))
						if (!banDef(bDroite, routesBanniesAToutJamais))
							routesPossible.add(bDroite);
				}
				if ((routes.get(i).getPosition().getColumn() == bHaut.getColumn() && routes.get(i).getPosition().getLine() == bHaut.getLine()) || (batimentPosition.getColumn() == bHaut.getColumn() && batimentPosition.getLine() == bHaut.getLine())) {
					if (!banTemp(bHaut, routesBanniesTemporairement))
						if (!banDef(bHaut, routesBanniesAToutJamais))
							routesPossible.add(bHaut);
				}
				if ((routes.get(i).getPosition().getColumn() == bGauche.getColumn() && routes.get(i).getPosition().getLine() == bGauche.getLine()) || (batimentPosition.getColumn() == bGauche.getColumn() && batimentPosition.getLine() == bGauche.getLine())) {
					if (!banTemp(bGauche, routesBanniesTemporairement))
						if (!banDef(bGauche, routesBanniesAToutJamais))
							routesPossible.add(bGauche);
				}
				if ((routes.get(i).getPosition().getColumn() == bBas.getColumn() && routes.get(i).getPosition().getLine() == bBas.getLine()) || (batimentPosition.getColumn() == bBas.getColumn() && batimentPosition.getLine() == bBas.getLine())){
					if (!banTemp(bBas, routesBanniesTemporairement))
						if (!banDef(bBas, routesBanniesAToutJamais))
							routesPossible.add(bBas);
				}
			}
			
			//1er cas : il y a un ou plusieurs chemins
			if (routesPossible.size()!=0) {
				currentPosition = routesPossible.get(0);
				for (int i=0; i<routesPossible.size(); i++) {
					if (CalculSegment(currentPosition, pnj)>CalculSegment(routesPossible.get(i), pnj)) {
						currentPosition = routesPossible.get(i);
					}
				}
				int size = routesPossible.size();
				for (int i=0; i<size;i++) {
					routesPossible.remove(0);
				}
				
				fausseRoute.add(currentPosition);
			}
			//3eme cas : finalement aucun chemin ne mene au batiment donc on sort de la boucle en trichant
			else if(currentPosition == pnj.getPosition()) {
				currentPosition = batimentPosition;
				erreur = true;
			}
			//2eme cas : le chemin emprunte ne mene pas au batiment, on recommence en enlevant ce chemin 
			else {
				routesBanniesAToutJamais.add(currentPosition);
				currentPosition = pnj.getPosition();
				int size = fausseRoute.size();
				for (int i=0; i<size;i++) {
					fausseRoute.remove(0);
				}
				int size2 = routesBanniesTemporairement.size();
				for (int i=0; i<size2;i++) {
					routesBanniesTemporairement.remove(0);
				}
			}
		}
		
		//Si on est sorti sauvagement de la boucle
		if (erreur == true) {
			int size = routesBanniesAToutJamais.size();
			for (int i=0; i<size;i++) {
				routesBanniesAToutJamais.remove(0);
			}
			int size2 = routesBanniesTemporairement.size();
			for (int i=0; i<size2;i++) {
				routesBanniesTemporairement.remove(0);
			}
		}
		else {
			pnj.setItineraire(fausseRoute);
			int size = routesBanniesAToutJamais.size();
			for (int i=0; i<size;i++) {
				routesBanniesAToutJamais.remove(0);
			}
			int size2 = routesBanniesTemporairement.size();
			for (int i=0; i<size2;i++) {
				routesBanniesTemporairement.remove(0);
			}
		}
		return erreur;
	}
	
	public List<Batiment> getBatiments() {
		return batiments;
	}
	public void setBatiments(List<Batiment> batiments) {
		this.batiments = batiments;
	}

	public int getRound() {
		return round;
	}
	public void setRound(int round) {
		this.round = round;
	}
	public List<Batiment> getBatimentsSurcharges() {
		return batimentsSurcharges;
	}
	public void setBatimentsSurcharges(List<Batiment> batimentsSurcharges) {
		this.batimentsSurcharges = batimentsSurcharges;
	}
	public boolean banDef(Block blockCote, List<Block> routesBanniesAToutJamais) {
		for (Block block : routesBanniesAToutJamais) {
			if (block.equals(blockCote))
				return true;
		}
		return false;
	}
	
	public boolean banTemp(Block blockCote, List<Block> routesBanniesTemporairement) {
		for (Block block : routesBanniesTemporairement) {
			if (block.equals(blockCote))
				return true;
		}
		return false;
	}
	
	public double CalculSegment(Block futurPosition,Pnj pnj) {
		//x= colonne
		//y= ligne
		double segment = Math.sqrt((Math.pow(pnj.getBatimentColonne()-futurPosition.getColumn(),2))+(Math.pow(pnj.getBatimentLine()-futurPosition.getLine(),2)));
		return segment;
	}
	
	public void PnjsExit() {
		List<Batiment> batimentSuppr = new ArrayList<Batiment>();
		for (Batiment attraction: batiments) {
			if  (attraction.getPnjs().size()!=0 && round%30==0) {
				Pnj pnj = attraction.getPnjs().get(0);
				attraction.getPnjs().remove(pnj);
				generateAnExitPnJ(attraction ,pnj);
				batimentSuppr.add(attraction);
				
			}
		}
		for (Batiment b : batimentSuppr) {
			batimentsSurcharges.remove(b);
		}
	}
	
	public void generateADailySalary() {
        int salaires=0;
        if(CalendrierGUI.getCalendrier().isEndOfTheDay2()) {
        for(Employe employe : EmployeManager.getContacts()) {
            salaires += employe.getSalaire()/30;
        }


        Tirelire.getInstance().calculArgent(-salaires);
        }
    }
	
	public void generateAnExitPnJ(Batiment attraction ,Pnj pnj ) {
		Block position = attraction.getPosition();
		pnj.setPosition(position);
		
		boolean bool = true;
		
		while (bool) {
			giveRandomBatimentExceptPorteEntreeEtDecoEtRoute(pnj);
			bool = CalculItineraire(pnj);
		}
		add(pnj);
	}
	
	public void nextRound() {
		generatePnJ();
		PnjsExit();
		movePnjs();
		GenerateSatisfaction();
		generateADailySalary();
		/* Sans le boolean, on va updateValues tout le temps le Bouton Niveau
		 * ce qui nuiera au MouseListener->MouseEntered de la classe Niveau 
		 * qui est cense afficher un message different
		 * si on place le curseur dessus
		 */
		if (Niveau.getInstance().getBool() == true) {
			Niveau.getInstance().updateValues();
			Niveau.getInstance().setBool(false);
		}
		round++;
	}
	public boolean isBatiment(Block block) {
		for (Batiment batiment : batiments) {
			if (batiment.getPosition().equals(block)) {
				return true;
			}
		}
		return false;
	}
	

	public boolean isDecoration(int i) {
		if(batiments.get(i).getType().equals("DECORATION")){
			return true;
		}
		return false ;
	}
	
	public boolean isMagasin(Block block) {
		for(Batiment batiment : batiments) {
			if(batiment.getPosition().equals(block) && batiment.getType().equals("MAGASIN")) {
				return true;
			}
		}
		return false ;
	}
	
	public boolean isPorteEntree(int i) {
		if(batiments.get(i).getType().equals("PORTEENTREE")) {
			return true;
		}
		return false ;
	}
	

	public boolean isRoute(int i) {
		if(batiments.get(i).getType().equals("ROUTE")){
			return true;
		}
		return false ;
	}
	
	public Puerta getPorteEntree() {
		for (Batiment batiment : batiments) {
			if (batiment.getType().equals("PORTEENTREE"))
				return (Puerta) batiment;
		}
		return null;
	}
	
	public Puerta getPorteSortie() {
		for (Batiment batiment : batiments) {
			if (batiment.getType().equals("PORTESORTIE"))
				return (Puerta) batiment;
		}
		return null;
	}
	
	public Batiment getBatiment(Block block) {
		for (Batiment batiment : batiments) {
			if (batiment.getPosition().equals(block))
				return batiment;
		}
		return null;
	}
	
	public Magasin getMagasin(Block block) {
		for (Batiment batiment : batiments) {
			if (batiment.getPosition().equals(block))
				return (Magasin) batiment;
		}
		return null;
	}
	
	public List<Attraction> getAttractions() {
		List<Attraction> attractions = new ArrayList<Attraction>();
		for (Batiment batiment : batiments) {
			if (batiment.getType().equals("ATTRACTION"))
				attractions.add((Attraction) batiment);
		}
		return attractions;
	}
	
	public List<Magasin> getMagasins() {
		List<Magasin> magasins = new ArrayList<Magasin>();
		for (Batiment batiment : batiments) {
			if (batiment.getType().equals("MAGASIN"))
				magasins.add((Magasin) batiment);
		}
		return magasins;
	}
	
	public List<Route> getRoutes() {
		List<Route> routes = new ArrayList<Route>();
		for (Batiment batiment : batiments) {
			if (batiment.getType().equals("ROUTE"))
				routes.add((Route) batiment);
		}
		return routes;
	}
	
	public boolean isARoute(Block block) {		
		for(Batiment batiment : batiments) {
			if(batiment.getPosition().equals(block) && batiment.getType().equals("ROUTE")) {
				return true;
			}
		}
		return false ;
	}
	
	public void GenerateSatisfaction() {
        if (CalendrierGUI.getCalendrier().isEndOfTheHour()) {
            Satisfaction.UpgradeSatisfaction(BatimentManager.Moyenne());
            Satisfaction.updateVariationSatisfaction(BatimentManager.Moyenne());
        }
    }
	
	public Map getMap() {
		return map;
	}
	public void setMap(Map map) {
		this.map = map;
	}
	
	
	public List<Pnj> getVisiteurs() {
		return visiteurs;
	}
	public void setVisiteurs(List<Pnj> visiteurs) {
		this.visiteurs = visiteurs;
	}
	
}