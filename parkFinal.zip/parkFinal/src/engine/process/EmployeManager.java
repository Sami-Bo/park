package engine.process;

import java.util.ArrayList;
import java.util.NoSuchElementException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

import engine.mobile.Employe;
import engine.mobile.Tirelire;


public class EmployeManager{
	
	private static ArrayList<Employe> contacts = new ArrayList<Employe>();
	
	public static void add(Employe contact) {
	        if(Tirelire.enoughMoney(contact.getSalaire())) {
	        contacts.add(contact);
	        Tirelire.getInstance().calculArgent(-contact.getSalaire());
	        Tirelire.updateVariationTirelire(-contact.getSalaire());
	        }
	        else {
	            JFrame frame = new JFrame("");
	            JLabel label = new JLabel("Vous n'avez pas assez d'argent");
	            frame.add(label);
	
	            frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	            frame.pack();
	            frame.setLocationRelativeTo(null);
	            frame.setVisible(true);
	            frame.setResizable(false);
	        }
	    }
	
	public Employe searchByName(String name, String prenom)throws NoSuchElementException {
		Employe result = null;
		//Using "for" loop
		for (Employe employe : contacts) {
			if (employe.getNom().equals(name)) {
				if(employe.getPrenom().equals(prenom)) {
					result = employe;
				}
			}
		}
		return result;
	}
	
	public static void remove(Employe employe) {
		
		contacts.remove(employe);
	}
	
	public int EmployeCount() {
		return contacts.size();
	}
	
	public static ArrayList<Employe> getContacts(){
		return contacts;
	}
	
	public static void setRoleEmploye(Employe employe) {
		for(int i=0; i< contacts.size();i++) {
			if(contacts.get(i)==employe) {
				contacts.get(i).setRole(employe.getRole());	
			}
		}
	}
}