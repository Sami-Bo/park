package engine.time;

import config.QueteConfiguration;

/**
 * The chronometer class is composed of the three cyclic counters. We can count until 59 hours 59 minutes and 59
 * seconds.
 * 
 * @author Tianxiao.Liu@u-cergy.fr
 **/
public class Calendrier {
	
	private CyclicCounter month = new CyclicCounter(1, 11, 1);
	private CyclicCounter day = new CyclicCounter(1, 30, 1);
	private CyclicCounter hour = new CyclicCounter(0, 23, 0);
	private CyclicCounter minute = new CyclicCounter(0, 59, 0);


	public void increment() {
			minute.increment();
			if (minute.getValue() == 0) {
				hour.increment();
				if (hour.getValue() == 0) {
					day.increment();
					 if(QueteConfiguration.quetetest2.isFinish()==false) {
							QueteConfiguration.quetetest2.setEtatEffectue();
						}
					if (day.getValue() == 1) {
						month.increment();
						 if(QueteConfiguration.quetetest4.isFinish()==false) {
								QueteConfiguration.quetetest4.setEtatEffectue();
							}
					}
				}
			}
		}

	
	public boolean isEndOfTheDay() {
		boolean reponse = false;
			if(minute.getValue() == 59) {
				if(hour.getValue() == 23) {
					reponse = true;
				}
			}
		return reponse;
	}
	
	public boolean isEndOfTheHour() {
        boolean reponse = false;
                if(minute.getValue() == 00) {
                    reponse = true;
                }

        return reponse;
    }
	
	public boolean isEndOfTheDay2() {
        boolean reponse = false;
            if(minute.getValue() == 58) {
                if(hour.getValue() == 22) {
                    reponse = true;
                }
            }
        return reponse;
    }

	public CyclicCounter getHour() {
		return hour;
	}

	public CyclicCounter getMinute() {
		return minute;
	}

	public CyclicCounter getDay() {
		return day;
	}
	
	public CyclicCounter getMonth() {
		return month;
	}

	public String toString() {
		return month.toString() + " : " + day.toString() + " : " + hour.toString() + " : " + minute.toString();
	}

	public static String transform(int value) {
		String result = "";
		if (value < 10) {
			result = "0" + value;
		} else {
			result = String.valueOf(value);
		}
		return result;
	}

	public void init() {
		month.setValue(1);
		day.setValue(1);
		hour.setValue(0);
		minute.setValue(0);
	}

}