package engine.mobile;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.lang.Math;

import construction.Batiment;

public class Employe {

	private String nom;
	private String prenom;
	private Batiment role;
	private int salaire;
	private int tauxEfficacite;
	
	
	public Employe (String nom,String prenom ,int tauxEfficacite) {
		this.setNom(nom);
		this.setPrenom(prenom);
		this.tauxEfficacite=tauxEfficacite;
		salaire = Employe.GenerateSalaire(tauxEfficacite);
		
	}
	
	public static String GenerateNom() throws IOException{
		int a= (int)(0+Math.random()*6);
		String nom2 = "";
		FileReader fr = new FileReader("src/CSV/Noms.csv");
	    BufferedReader br = new BufferedReader(fr);
		
	    for (int i=0;i<= a;i++) {
           String line = br.readLine();
           nom2=line;
        }
	    
		br.close();
		fr.close();
		return nom2;
		}		


	public static String GeneratePrenom() throws IOException{
		int a= (int)(0+Math.random()*7);
		String prenom2 = "";
		FileReader fr = new FileReader("src/CSV/Prenoms.csv");
	    BufferedReader br = new BufferedReader(fr);
		
	    for (int i=0;i<= a;i++) {
           String line = br.readLine();
           prenom2=line;
        }
	    
		br.close();
		fr.close();
		return prenom2;
		}
	
	public static int GenerateEfficacite() {
		int efficacite = (int)(Math.random()*100);
		if(efficacite<20) {
			efficacite=GenerateEfficacite();
		}
		return efficacite;
	}
	
	public static int GenerateSalaire(int efficacite) {
		int salaire = efficacite*30 ;
		return salaire;
	}

	public String getNom() {
		return nom;
		}


	public void setNom(String nom) {
		this.nom = nom;
		}


	public String getPrenom() {
		return prenom;
	}


	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	
	public void setRole(Batiment batiment) {
		this.role=batiment;
	}
	
	public Batiment getRole() {
		return role;
	}
	
	public int getSalaire() {
		return salaire;
	}
	
	public int getEfficacite() {
		return tauxEfficacite;
	}
	
	public boolean hasRole(Employe employe) {
		if(employe.getRole()!=null){
			return true;
		}
		else {
			return false;
		}
	}
}