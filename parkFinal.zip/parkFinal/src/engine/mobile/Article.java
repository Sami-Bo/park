package engine.mobile;

public class Article {
	private int price;
	private int chanceDetreAchete;
	private String nom ;
	
	public Article(int price, int chanceDetreAchete , String nom) {
		this.price = price;
		this.chanceDetreAchete = chanceDetreAchete;
		this.nom = nom;
	}
	
	public int getPrix() {
		return price;
	}
	
	public int getChanceAchat() {
		return chanceDetreAchete;
	}
	
	public String getNom() {
		return nom;
	}
}