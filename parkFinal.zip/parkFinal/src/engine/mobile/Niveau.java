package engine.mobile;

import gui.BoutonsEnHaut;

public class Niveau{
	
	private int niveau = 1;
	private int expAvantSuivant=50;
	private int exprequis = 50;
	
	private static Niveau niv = new Niveau();
	private boolean up = false;
	
	private Niveau () {
		 
	}
		 
	
	 public void lvlUp() {
		 if (expAvantSuivant <= 0 ){ 
				int surplus = -expAvantSuivant;
				augmentationExpRequis();
				expAvantSuivant = exprequis;
				niveau = niveau+1;
				expAvantSuivant -= surplus;
				up = true;
		  }
	 }
	 //si on a plus d'xp que n�cessaire l'xp avant suivant se r�duit durant le lvl up 
	 public void augmentationExpRequis() { 
		 exprequis = 2*exprequis ;
	 }
	 
	 public void xpUp(int xp) {
		 expAvantSuivant= expAvantSuivant-xp;
		 lvlUp();
	 }
	 
	 public boolean getBool() {
		 return up;
	 }
	 
	 public void setBool(boolean a) {
		 up = a;
	 }
	 
	 public static Niveau getInstance() {
		 return niv;
	 }
	 
	 public int getNiveau() {
		 return niveau;
	 }
	 
	 public int getExpAvantSuivant() {
		 return expAvantSuivant;
	 }
	 
	 public int getExpRequis() {
		 return exprequis;
	 }
	 
	 public void updateValues() {
			// This part is for textual time printing.
			BoutonsEnHaut.getInstance().setNiveau(niveau);
	 }
}