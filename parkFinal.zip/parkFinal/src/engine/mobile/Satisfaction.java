package engine.mobile;

import gui.MenuInformationRessources;

public class Satisfaction {
	private static final int min=0;
	private static final int max =100;
	private static int taux ;
	
	private static Satisfaction satisfaction = new Satisfaction() ;
	private static int variationSatisfaction=0;
	
	private Satisfaction(){ 
		taux=75;
	}
	
	public static void UpgradeSatisfaction(int bonus) {
		taux = taux + bonus;
		if (taux>max) {
			taux = 100;
			}
		MenuInformationRessources.getInstance().setSatisfaction();
		}
	
	public static void DowngradeSatisfaction() {
		taux = taux-1;
			if(taux<min) 
			{
				taux = 0;
			}
		MenuInformationRessources.getInstance().setSatisfaction();
	}
	
	public static int getTaux() {
		return taux;
	}
	
	public static void setTaux(int taux) {
		Satisfaction.taux = taux;
	}
	
	public static void updateVariationSatisfaction(int i) {
		Satisfaction.variationSatisfaction+=i;
	}
	
	public static int getVariationSatisfaction() {
		return Satisfaction.variationSatisfaction;
	}
	
	public static void restartVariationSatisfaction() {
		Satisfaction.variationSatisfaction=0;
	}
	
}
