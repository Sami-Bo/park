package engine.mobile;

import java.util.ArrayList;
import java.util.List;

import construction.Batiment;
import engine.map.Block;

public class Pnj extends Element {
	private int avis; 
	private List<Block> itineraire = new ArrayList<Block>();
	private Batiment batimentArrive;
	
	public Pnj(int avis, Block position){
		super(position);
		this.avis= avis;
	}

	
	public int getAvis() {
		return avis;
	}

	public void setAvis(int avis) {
		this.avis = avis;
	}

	public static int getRandomNumber() {
		return (int) (Math.random() * 59) + 12;
		
}


	public void setBatiment(Batiment batiment) {
		batimentArrive = batiment;
		// TODO Auto-generated method stub
		
	}

	public Batiment getBatiment() {
		return batimentArrive;
	}

	public int getBatimentLine() {
		return batimentArrive.getPosition().getLine();
		
		// TODO Auto-generated method stub
		
	}
	public int getBatimentColonne() {
		return batimentArrive.getPosition().getColumn();
		
		// TODO Auto-generated method stub
		
	}
	
	public void setItineraire(List<Block> itineraire) {
		this.itineraire = itineraire;
	}
	
	public List<Block> getItineraire(){
		return itineraire;
	}
}