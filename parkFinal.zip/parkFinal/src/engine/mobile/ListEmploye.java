package engine.mobile;

import java.util.ArrayList;
import java.util.NoSuchElementException;



public class ListEmploye{
	
	
		private ArrayList<Employe> contacts;
		
		
		public ListEmploye() {
			contacts = new ArrayList<Employe>();
		}

		public void add(Employe contact) {
			contacts.add(contact);
		}

		public Employe searchByName(String name)throws NoSuchElementException {
			Employe result = null;
			//Using "for" loop
			for (Employe employe : contacts) {
				if (employe.getNom().equals(name)) {
					result = employe;
				}
			}
			return result;
		}

		
		public Employe searchByPrenom(String name)throws NoSuchElementException {
			Employe result = null;
			//Using "for" loop
			for (Employe employe : contacts) {
				if (employe.getPrenom().equals(name)) {
					result = employe;
				}
			}
			return result;
		}


		public void remove(Employe employe) {
			
			contacts.remove(employe);
		}

		public int EmployeCount() {
			return contacts.size();
		}

	}