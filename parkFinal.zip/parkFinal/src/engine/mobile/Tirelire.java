package engine.mobile;

public class Tirelire {
	private float argent;
	
	private static Tirelire tirelire = new Tirelire(0);
	private static float variationTirelire = 0 ;
	private static float prixEntree = 50;
	
	private Tirelire (float argent){
		this.argent= argent;	
	}
	
	public void calculArgent(float recompense) {
		argent += recompense;
	}
	
	public float getArgent() {
		return argent;
	}
	
	public static Tirelire getInstance() {
		return tirelire;
	}
	
	public void initTirelire(String difficulte){
		switch(difficulte) {
		case "facile":
		argent = 500;
		break;
		case "normale":
		argent = 250;
		break;
		case "difficile":
		argent = 100;
		break;
		}
	}
	
	public static void updateVariationTirelire(float i) {
		Tirelire.variationTirelire+=i;
	}
	
	public static float getVariationTirelire() {
		return Tirelire.variationTirelire;
	}
	
	public static void restartVariationTirelire() {
		Tirelire.variationTirelire=0;
	}
	
	public static boolean enoughMoney(float cost) {
		boolean retour = false ;
		if(Tirelire.getInstance().getArgent()>=cost) {
			retour=true;
		}
		return retour;
	}
	
	public static float getPrixEntree() {
		return prixEntree;
	}
	
	public static void setPrixEntree(float prixsup) {
		Tirelire.prixEntree+=prixsup;
	}

}