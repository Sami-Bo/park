package engine.mobile;

public class Quete {
	
	private String name;
	private String description;
	private int recompenseArgent ;
	private int recompenseXP ;
	private String etat;
	private int recupere ;


	public Quete(String name, String description, int recompenseArgent, int recompenseXP) {
		this.name=name;
		this.description=description;
		this.recompenseArgent=recompenseArgent;
		this.recompenseXP=recompenseXP;
		etat="Non Effectu�";
		recupere = 0;
	}
	
	public String getEtat() {
		return etat;
	}
	
	public void setEtatEffectue() {
		this.etat="Effectu�" ;
	}
	
	public boolean isFinish() {
		boolean bool = false;
		if(etat=="Effectu�") {
			bool= true;
		}
		return bool;
	}
	
	public int getRecupere() {
		return recupere;
	}
	
	public void setRecupere() {
		recupere=1;
	}
	
	public boolean alreadyRecupere() {
		boolean bool = false;
		if(recupere==1) {
			bool = true;
		}
		return bool;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public int getRecompenseArgent() {
		return recompenseArgent;
	}
	
	public int getRecompenseXP() {
		return recompenseXP;
	}
}
