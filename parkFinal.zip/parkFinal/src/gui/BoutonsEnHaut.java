package gui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import engine.mobile.Niveau;
import gui.secondaire.Aide;


public class BoutonsEnHaut {

	/*
	 * Attribut Panel conteneur des boutons d'info
	 */
	private JPanel boite = new JPanel();
	
	private MenuInformationRessources menuInfoRessources = MenuInformationRessources.getInstance();
	private CalendrierGUI calendrier = new CalendrierGUI();
	
	/*
	 * Boutons d'info
	 */
	private JButton niveauButton = new JButton("Niveau 1");
	private JButton newsButton = new JButton("Aide");
	
	private Mouse mickeyMouse = new Mouse();
	
	private static Niveau niv = Niveau.getInstance();
	
	private static BoutonsEnHaut bth = new BoutonsEnHaut();
		
	private BoutonsEnHaut() {
		//Placement des boutons dans la Frame//
		boite.setLayout(new FlowLayout());
		
		boite.add(menuInfoRessources.getBoiteMenuInfoRessource());
		
		boite.add(calendrier.getPanel());
		
		boite.add(niveauButton);
		niveauButton.addMouseListener(mickeyMouse);

		boite.add(newsButton);
		newsButton.addActionListener(new NewsAction());
	}
	
	public void setNiveau(int a) {
		niveauButton.setText("Niveau " + a);
	}
	
	public JPanel getBoiteMenuInfoRessource() {
		return boite;
	}
	
	public static BoutonsEnHaut getInstance() {
		return bth;
	}
	
	private class NewsAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			Aide aide = new Aide("Aide");
		}
	}
	
	public class Mouse extends JFrame implements MouseListener {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			niveauButton.setText(niv.getExpAvantSuivant() +" xp requis");
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			niveauButton.setText("Niveau " + niv.getNiveau());
		}
		
	}

}