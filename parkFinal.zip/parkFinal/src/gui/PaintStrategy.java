package gui;

import java.awt.Color;
import java.awt.Graphics;

import config.GameConfiguration;

import construction.Attraction;
import construction.Batiment;
import construction.Decoration;
import construction.Magasin;
import construction.Puerta;
import construction.Route;
import engine.map.Block;
import engine.map.Map;
import engine.mobile.Pnj;
/**
 * Copyright SEDAMOP - Software Engineering
 * 
 * @author tianxiao.liu@cyu.fr
 *
 */
public class PaintStrategy {
	public void paint(Map map, Graphics graphics) {
		int blockSize = GameConfiguration.BLOCK_SIZE;
		Block[][] blocks = map.getBlocks();

		for (int lineIndex = 0; lineIndex < map.getLineCount(); lineIndex++) {
			for (int columnIndex = 0; columnIndex < map.getColumnCount(); columnIndex++) {
				Block block = blocks[lineIndex][columnIndex];

				//if ((lineIndex + columnIndex) % 2 == 0) {
					graphics.setColor(Color.GREEN);
					graphics.fillRect(block.getColumn() * blockSize, block.getLine() * blockSize, blockSize, blockSize);
				//}
			}
		}
	}
	
	public void paint(Map map, int a, Graphics graphics) {
		int blockSize = GameConfiguration.BLOCK_SIZE;
		Block[][] blocks = map.getBlocks();
		
		for (int lineIndex = 0; lineIndex < map.getLineCount(); lineIndex++) {
			for (int columnIndex = 0; columnIndex < map.getColumnCount(); columnIndex++) {
				Block block = blocks[lineIndex][columnIndex];
					graphics.setColor(Color.GRAY);
					graphics.fillRect(block.getColumn() * blockSize, block.getLine() * blockSize, blockSize, blockSize);
			}
		}
	}

	public void paint(Decoration deco, Graphics graphics) 
	{
		Block position = deco.getPosition();
		int blockSize = GameConfiguration.BLOCK_SIZE;

		int[]taille = deco.getTaille();
		
		for(int i=0;i<taille[0]; i++) 
		{
			for(int j=0; j<taille[1]; j++) 
			{
				int y = position.getLine();
				int x = position.getColumn();
				graphics.setColor(Color.GREEN);
				graphics.fillRect(x * blockSize, y * blockSize, blockSize, blockSize);
			}
		}
	}
	
	public void paint(Pnj pnj, Graphics graphics) {
        Block position = pnj.getPosition();
        int blockSize = GameConfiguration.BLOCK_SIZE;

        int y = position.getLine();
        int x = position.getColumn();

        graphics.setColor(Color.RED);
        graphics.fillOval(x * blockSize, y * blockSize, blockSize, blockSize);
    }

    public void paint(Puerta porte, Graphics graphics) {
        Block position = porte.getPosition();
        int blockSize = GameConfiguration.BLOCK_SIZE;

        int y = position.getLine();
        int x = position.getColumn();

        graphics.setColor(Color.ORANGE);
        graphics.fillRect(x * blockSize, y * blockSize, blockSize, blockSize);
    }
    
    public void paint(Route route, Graphics graphics) {
        Block position = route.getPosition();
        int blockSize = GameConfiguration.BLOCK_SIZE;

        int y = position.getLine();
        int x = position.getColumn();

        graphics.setColor(Color.GRAY);
        graphics.fillRect(x * blockSize, y * blockSize, blockSize, blockSize);
    }
    
    public void paint(Attraction attraction, Graphics graphics) {
        Block position = attraction.getPosition();
        int blockSize = GameConfiguration.BLOCK_SIZE;

        int y = position.getLine();
        int x = position.getColumn();

        graphics.setColor(Color.BLUE);
        graphics.fillRect(x * blockSize, y * blockSize, blockSize, blockSize);
    }
    
    public void paint(Magasin magasin , Graphics graphics) {
        Block position = magasin.getPosition();
        int blockSize = GameConfiguration.BLOCK_SIZE;

        int y = position.getLine();
        int x = position.getColumn();

        graphics.setColor(Color.WHITE);
        graphics.fillRect(x * blockSize, y * blockSize, blockSize, blockSize);
    }
    
    public void paint(Graphics graphics, Batiment magasin) {
        Block position = magasin.getPosition();
        int blockSize = GameConfiguration.BLOCK_SIZE;

        int y = position.getLine();
        int x = position.getColumn();

        graphics.setColor(Color.BLACK);
        graphics.fillRect(x * blockSize, y * blockSize, blockSize, blockSize);
    }
}