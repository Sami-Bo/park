package gui;

import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import config.GameConfiguration;
import engine.time.Calendrier;
import engine.time.CyclicCounter;

/**
 * Main GUI class for chronometer.
 * 
 * @author Tianxiao.Liu@u-cergy.fr
 **/
public class CalendrierGUI extends JFrame implements Runnable {

	private static Font font = new Font(Font.MONOSPACED, Font.BOLD, 20);

	/**
	 * The normal speed is 1000, e.q. one refresh per second (1000 milliseconds).
	 */
	private static int chronoSpeed = 100;

	private static final long serialVersionUID = 1L;

	/**
	 * The core functional part : the chronometer.
	 */
	private static Calendrier calendrier = new Calendrier();

	private JLabel monthLabel = new JLabel("M:");
	private JLabel dayLabel = new JLabel("D:");
	private JLabel hourLabel = new JLabel("H:");
	private JLabel minuteLabel = new JLabel("M:");

	private JLabel monthValue = new JLabel("");
	private JLabel dayValue = new JLabel("");
	private JLabel hourValue = new JLabel("");
	private JLabel minuteValue = new JLabel("");

	private JPanel control = new JPanel();
	/**
	 * This instance is used in the inner classes for different action listeners.
	 */
	private CalendrierGUI instance = this;

	/**
	 * Initial status of for the start button.
	 */
	private boolean stop = true;

	public CalendrierGUI() {
		
		updateValues();

		control.setLayout(new FlowLayout(FlowLayout.CENTER));
		
		monthLabel.setFont(font);
		control.add(monthLabel);
		monthValue.setFont(font);
		control.add(monthValue);
		
		dayLabel.setFont(font);
		control.add(dayLabel);
		dayValue.setFont(font);
		control.add(dayValue);
		
		hourLabel.setFont(font);
		control.add(hourLabel);
		hourValue.setFont(font);
		control.add(hourValue);

		minuteLabel.setFont(font);
		control.add(minuteLabel);
		minuteValue.setFont(font);
		control.add(minuteValue);
		
	}
	
	public JPanel getPanel() {
		stop = false;
		Thread chronoThread = new Thread(instance);
		chronoThread.start();
		return control;
	}
	
	public static int getChronoSpeed() {
		return chronoSpeed;
	}

	public static void setChronoSpeed(int speed) {
		CalendrierGUI.chronoSpeed = speed;
	}
	
	private void updateValues() {
		// This part is for textual time printing.
		CyclicCounter month = calendrier.getMonth();
		monthValue.setText(month.toString() + " ");
		
		CyclicCounter day = calendrier.getDay();
		dayValue.setText(day.toString() + " ");
		
		CyclicCounter hour = calendrier.getHour();
		hourValue.setText(hour.toString() + " ");

		CyclicCounter minute = calendrier.getMinute();
		minuteValue.setText(minute.toString() + " ");

	}
	
	public static Calendrier getCalendrier() {
		return calendrier;
	}

	/**
	 * Defines what to do for each time unit (by default 1 second) : it increments the chronometer
	 */
	@Override
	public void run() {
		while (!stop) {
			try {
				Thread.sleep(getChronoSpeed());
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
			try {
				if(calendrier.isEndOfTheDay()) {
					Thread.sleep(GameConfiguration.PAUSE_JOURNEES);
				}
			}catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
			calendrier.increment();
			
			// Ensure that the chronometer is not stopped during the iteration.
			if (!stop) {
				updateValues();
			}
		}
	}
}