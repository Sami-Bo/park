package gui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

import gui.secondaire.MenuAttractions;
import gui.secondaire.MenuDecoration;
import gui.secondaire.MenuEmploye;
import gui.secondaire.MenuMagasin;

/**
 * Classe Graphique pour le Menu de construction des batiments
 * @author Thomas
 * @date 09/02/2022
 */

public class MenuConstructionBatiments {
	
	/*
	 * Le Menu de Construction (Boite contennant les JButton)
	 */
	private JPanel boiteMenuConstru = new JPanel();
	
	/*
	 *Les Differents JButton que contiendront le Menu (ils correspondent aux differents type de batiments).
	 */
	private JButton listEmployeButton = new JButton("Employes") ;
	private JButton routeButton = new JButton("Route") ;
	private JButton attractionButton = new JButton("Attraction") ;
	private JButton magasinButton = new JButton("Magasin") ;
	private JButton decorationButton = new JButton("Decoration") ;
	
	public MenuConstructionBatiments() {
				
		//Placement des differents Bouttons//
		boiteMenuConstru.setLayout(new FlowLayout(FlowLayout.CENTER));
		
		boiteMenuConstru.add(decorationButton);
		boiteMenuConstru.add(routeButton);
		boiteMenuConstru.add(attractionButton);
		boiteMenuConstru.add(magasinButton);
		boiteMenuConstru.add(listEmployeButton);

		decorationButton.addActionListener(new DecorationAction());
		listEmployeButton.addActionListener(new EmployeButton());
		routeButton.addActionListener(new RouteAction());
		attractionButton.addActionListener(new AttractionAction());
		magasinButton.addActionListener(new MagasinAction());
	}
	
	public JPanel getBoiteMenuConstru() {
		return boiteMenuConstru;
	}

	public boolean isModeActive() {
		if (getModeAttractionActive() || getModeDecorationActive() || getModeMagasinActive() || getModeRouteActive())
			return true;
		return false;
	}
	
	public boolean getModeRouteActive() {
		if (routeButton.getText().equals("Route"))
			return false;
		else 
			return true;
	}
	
	public boolean getModeAttractionActive() {
		if (attractionButton.getText().equals("Attraction"))
			return false;
		else 
			return true;
	}
	public boolean getModeMagasinActive() {
		if (magasinButton.getText().equals("Magasin"))
			return false;
		else 
			return true;
	}
	
	public boolean getModeDecorationActive() {
		if (decorationButton.getText().equals("Decoration"))
			return false;
		else 
			return true;
	}
	
	public void setAttractionButton() {
        attractionButton.setText("Attraction");
    }
	
	public void setMagasinButton() {
        magasinButton.setText("Magasin");
    }
	
	public void setDecorationButton() {
		decorationButton.setText("Decoration");
	}
	
	public void setAllButtons(String mode) {
		attractionButton.setText("Attraction");
		decorationButton.setText("Decoration");
		magasinButton.setText("Magasin");
		routeButton.setText("Route");
		if (mode.equals("A")) {
			attractionButton.setText("ATTRACTION");
		}
		if (mode.equals("D")) {
			decorationButton.setText("DECORATION");
		}
		if (mode.equals("M")) {
			magasinButton.setText("MAGASIN");
		}
		if (mode.equals("R")) {
			routeButton.setText("ROUTE");
		}
	}
	
	private void initButtons() {
		MenuAttractions.initAttractionChoisi();
		MenuDecoration.initDecorationChoisi();
		MenuMagasin.initMagasinChoisi();
	}
	
	private class EmployeButton implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

            MenuEmploye employe = new MenuEmploye("Employ�s");
            employe.setVisible(true);
        }
    }
	
    private class AttractionAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (attractionButton.getText().equals("Attraction")) {
				setAllButtons("A");
				initButtons();
				MenuAttractions menuattraction = new MenuAttractions("Attraction");
			}else
				attractionButton.setText("Attraction");
		}
    }
    
    private class DecorationAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (decorationButton.getText().equals("Decoration")) {
				setAllButtons("D");
				initButtons();
				MenuDecoration menuDecoration = new MenuDecoration("Decoration");
			}else
				decorationButton.setText("Decoration");
		}
    }
    
	private class MagasinAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			if (magasinButton.getText().equals("Magasin")) {
				setAllButtons("M");
				initButtons();
				MenuMagasin menuMagasin = new MenuMagasin("Magasin") ;
			}else
				magasinButton.setText("Magasin");
		}
	}
	
	private class RouteAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (routeButton.getText().equals("Route")) {
				initButtons();
				setAllButtons("R");
			}else
				routeButton.setText("Route");
		}
	}
}
