package gui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

import config.GameConfiguration;
import engine.mobile.Satisfaction;
import engine.mobile.Tirelire;

/**
 * Classe Graphique pour le Menu de construction des batiments
 * @author Thomas
 * @date 09/02/2022
 */

public class MenuInformationRessources {

	/*
	 * Attribut Panel conteneur des boutons d'info
	 */
	private JPanel boiteMenuInfoRessource = new JPanel();
	
	/*
	 * Boutons d'info
	 */
	private JButton argentButton = new JButton("0$");
	private JButton satisfactionButton = new JButton();
	private JButton speedTimeButton = new JButton("x1") ;
	
	private Tirelire tirelire = Tirelire.getInstance();
	private static MenuInformationRessources m = new MenuInformationRessources();
	
	private MenuInformationRessources() {
		//Placement des boutons dans la Frame//
		boiteMenuInfoRessource.setLayout(new FlowLayout(FlowLayout.LEFT));
		
		tirelire.initTirelire(GameConfiguration.DIFICULTE);
		String text = String.valueOf(tirelire.getArgent());
		argentButton.setText(text + "$");
		boiteMenuInfoRessource.add(argentButton);
		
		String textSatisfaction =  String.valueOf(Satisfaction.getTaux());
		satisfactionButton.setText(textSatisfaction + "%");
		boiteMenuInfoRessource.add(satisfactionButton);		
		
		boiteMenuInfoRessource.add(speedTimeButton);
		speedTimeButton.addActionListener(new SpeedAction());
	}
	
	public JPanel getBoiteMenuInfoRessource() {
		return boiteMenuInfoRessource;
	}
	
	public static MenuInformationRessources getInstance() {
		return m;
	}
	
	public void setArgent() {
		String text = String.valueOf(tirelire.getArgent());
		argentButton.setText(text + "$");
	}
	
	public void setSatisfaction() {
		String textSatisfaction = String.valueOf(Satisfaction.getTaux());
		satisfactionButton.setText(textSatisfaction + "%");
	}

	private class SpeedAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			int speed = CalendrierGUI.getChronoSpeed();
			String a = speedTimeButton.getText();
			switch(a) {
				case "x1" : CalendrierGUI.setChronoSpeed(speed/2);
				speedTimeButton.setText("x2");
				break;
				case "x2" : CalendrierGUI.setChronoSpeed(speed/2);
				speedTimeButton.setText("x4");
				break;
				case "x4" : CalendrierGUI.setChronoSpeed(speed*4);
				speedTimeButton.setText("x1");
				break;
			}
		}
	}
}
