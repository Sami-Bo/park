package gui.secondaire;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import config.DecorationConfiguration;
import construction.Decoration;
import engine.mobile.Niveau;
import engine.mobile.Tirelire;

public class MenuDecoration extends JFrame {
	
	private static Decoration decoChoisi ;
		
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(800, 600);

	private static final long serialVersionUID = 1L;
	
	private static Font font = new Font(Font.MONOSPACED, Font.BOLD, 30);
	
	private JPanel control = new JPanel();
		
	private JButton buttonarbre = new JButton(DecorationConfiguration.arbre.getNom());
	private JButton buttonfontaine = new JButton(DecorationConfiguration.fontaine.getNom());
	private JButton buttonbanc = new JButton(DecorationConfiguration.banc.getNom());
	private JButton buttonfleur = new JButton(DecorationConfiguration.fleur.getNom());
	private JButton buttonetang = new JButton(DecorationConfiguration.etang.getNom());
	private JButton buttonstatue = new JButton(DecorationConfiguration.statue.getNom());
		
	private JLabel lab = new JLabel();
			
	public MenuDecoration(String title){
		super(title);
		init();
	}
	
	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		control.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 40));
		control.setPreferredSize(new Dimension(400,700));

		buttonarbre.addActionListener(new DecorationAction(DecorationConfiguration.arbre));
		buttonarbre.addMouseListener(new Mouse(DecorationConfiguration.arbre));
		buttonarbre.setFont(font);
		control.add(buttonarbre);
		
		buttonfontaine.addActionListener(new DecorationAction(DecorationConfiguration.fontaine));
		buttonfontaine.addMouseListener(new Mouse(DecorationConfiguration.fontaine));
		buttonfontaine.setFont(font);
		control.add(buttonfontaine);

		buttonbanc.addActionListener(new DecorationAction(DecorationConfiguration.banc));
		buttonbanc.addMouseListener(new Mouse(DecorationConfiguration.banc));
		buttonbanc.setFont(font);
		control.add(buttonbanc);
		
		buttonfleur.addActionListener(new DecorationAction(DecorationConfiguration.fleur));
		buttonfleur.addMouseListener(new Mouse(DecorationConfiguration.fleur));
		buttonfleur.setFont(font);
		control.add(buttonfleur);
		
		buttonetang.addActionListener(new DecorationAction(DecorationConfiguration.etang));
		buttonetang.addMouseListener(new Mouse(DecorationConfiguration.etang));
		buttonetang.setFont(font);
		control.add(buttonetang);
		
		buttonstatue.addActionListener(new DecorationAction(DecorationConfiguration.statue));
		buttonstatue.addMouseListener(new Mouse(DecorationConfiguration.statue));
		buttonstatue.setFont(font);
		control.add(buttonstatue);
		
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));

		contentPane.add(BorderLayout.NORTH, control);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setPreferredSize(IDEAL_MAIN_DIMENSION);
		setResizable(true);
	}
	
	public void setLabelText(Decoration d) {
		lab.setText(" Niveau : " + d.getLevelRequered() + " Prix : " + d.getPrix() +"$ Xp : " + d.getBonusSatisfaction());
	}
		
	public static Decoration getDecorationChoisi() {
		return decoChoisi;
	}
	
	public static void initDecorationChoisi() {
		decoChoisi = null;
	}
	
	public JButton getButton(String name) {
		if (name.equals(DecorationConfiguration.arbre.getNom()))
				return buttonarbre;
		else if (name.equals(DecorationConfiguration.fontaine.getNom()))
				return buttonfontaine;
		else if (name.equals(DecorationConfiguration.banc.getNom()))
				return buttonbanc;
		else if (name.equals(DecorationConfiguration.fleur.getNom()))
				return buttonfleur;
		else if (name.equals(DecorationConfiguration.statue.getNom()))
			return buttonstatue;
		else if (name.equals(DecorationConfiguration.etang.getNom()))
			return buttonetang;
		else
			return null;
	}
	
	private class DecorationAction implements ActionListener{
		private Decoration deco ;
		public DecorationAction(Decoration deco) {
			this.deco=deco;
		}
		
		public void actionPerformed(ActionEvent e) {
			decoChoisi=deco;
			dispose();
		}
	}

	public class Mouse extends JFrame implements MouseListener {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private JButton b;
		
		Decoration deco;
        public Mouse(Decoration deco)
        {
            this.deco = deco;
			b = getButton(deco.getNom());
        }
         
		
		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
			if (deco.getPrix()>Tirelire.getInstance().getArgent() || Niveau.getInstance().getNiveau() < deco.getLevelRequered()) {
				b.setEnabled(false);
			}
			setLabelText(deco);
			control.add(lab);
			control.updateUI();
		}
			

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub 
			b.setEnabled(true);
			control.remove(lab);
			control.updateUI();
		}
		
	}
}