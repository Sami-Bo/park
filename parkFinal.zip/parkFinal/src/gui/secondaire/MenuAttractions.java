package gui.secondaire;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import config.AttractionConfiguration;
import construction.Attraction;
import engine.mobile.Niveau;
import engine.mobile.Tirelire;

public class MenuAttractions extends JFrame {
	
	private static Attraction attractionChoisi ;
		
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(800, 600);

	private static final long serialVersionUID = 1L;
	
	private static Font font = new Font(Font.MONOSPACED, Font.BOLD, 30);
	
	private JPanel control = new JPanel();
		
	JButton buttonRollerCoaster = new JButton(AttractionConfiguration.RoallerCoaster.getNom());
	JButton buttonMaisonHantee = new JButton(AttractionConfiguration.MaisonEnThe.getNom());
	JButton buttonGrandSplash = new JButton(AttractionConfiguration.GrandSplash.getNom());
	JButton buttonGrandeRoue = new JButton(AttractionConfiguration.GrandeRoue.getNom());
	JButton buttonAutoTamponeuse = new JButton(AttractionConfiguration.AutoTamponeuse.getNom());
	JButton buttonLabyrinthe = new JButton(AttractionConfiguration.Labyrinthe.getNom());
	JButton buttonGuerreDuCosmos = new JButton(AttractionConfiguration.GuerreDuCosmos.getNom());
		
	private JLabel lab = new JLabel();
			
	public MenuAttractions(String title){
		super(title);
		init();
	}
	
	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		control.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 40));
		control.setPreferredSize(new Dimension(400,700));

		buttonRollerCoaster.addActionListener(new AttractionAction(AttractionConfiguration.RoallerCoaster));
		buttonRollerCoaster.addMouseListener(new Mouse(AttractionConfiguration.RoallerCoaster));
		buttonRollerCoaster.setFont(font);
		control.add(buttonRollerCoaster);
		
		buttonGrandSplash.addActionListener(new AttractionAction(AttractionConfiguration.GrandSplash));
		buttonGrandSplash.addMouseListener(new Mouse(AttractionConfiguration.GrandSplash));
		buttonGrandSplash.setFont(font);
		control.add(buttonGrandSplash);
		
		buttonGrandeRoue.addActionListener(new AttractionAction(AttractionConfiguration.GrandeRoue));
		buttonGrandeRoue.addMouseListener(new Mouse(AttractionConfiguration.GrandeRoue));
		buttonGrandeRoue.setFont(font);
		control.add(buttonGrandeRoue);
		
		buttonMaisonHantee.addActionListener(new AttractionAction(AttractionConfiguration.MaisonEnThe));
		buttonMaisonHantee.addMouseListener(new Mouse(AttractionConfiguration.MaisonEnThe));
		buttonMaisonHantee.setFont(font);
		control.add(buttonMaisonHantee);
		
		buttonAutoTamponeuse.addActionListener(new AttractionAction(AttractionConfiguration.AutoTamponeuse));
		buttonAutoTamponeuse.addMouseListener(new Mouse(AttractionConfiguration.AutoTamponeuse));
		buttonAutoTamponeuse.setFont(font);
		control.add(buttonAutoTamponeuse);
		
		buttonLabyrinthe.addActionListener(new AttractionAction(AttractionConfiguration.Labyrinthe));
		buttonLabyrinthe.addMouseListener(new Mouse(AttractionConfiguration.Labyrinthe));
		buttonLabyrinthe.setFont(font);
		control.add(buttonLabyrinthe);
		
		buttonGuerreDuCosmos.addActionListener(new AttractionAction(AttractionConfiguration.GuerreDuCosmos));
		buttonGuerreDuCosmos.addMouseListener(new Mouse(AttractionConfiguration.GuerreDuCosmos));
		buttonGuerreDuCosmos.setFont(font);
		control.add(buttonGuerreDuCosmos);
		
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));

		contentPane.add(BorderLayout.NORTH, control);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setPreferredSize(IDEAL_MAIN_DIMENSION);
		setResizable(true);
	}
	
	public void setLabelText(Attraction d) {
		lab.setText(" Niveau : " + d.getLevelRequered() + " Prix : " + d.getPrix() +"$ Xp : " + d.getBonusExp());
	}
	
	public static Attraction getAttractionChoisi() {
		return attractionChoisi;
	}
	
	public static void initAttractionChoisi() {
		attractionChoisi = null;
	}
	
	public JButton getButton(String name) {
		if (name.equals(AttractionConfiguration.RoallerCoaster.getNom()))
				return buttonRollerCoaster;
		else if (name.equals(AttractionConfiguration.GrandeRoue.getNom()))
				return buttonGrandeRoue;
		else if (name.equals(AttractionConfiguration.GrandSplash.getNom()))
				return buttonGrandSplash;
		else if (name.equals(AttractionConfiguration.MaisonEnThe.getNom()))
				return buttonMaisonHantee;
		else if (name.equals(AttractionConfiguration.AutoTamponeuse.getNom()))
			return buttonAutoTamponeuse;
		else if (name.equals(AttractionConfiguration.Labyrinthe.getNom()))
			return buttonLabyrinthe;
		else if (name.equals(AttractionConfiguration.GuerreDuCosmos.getNom()))
			return buttonGuerreDuCosmos;
		else
			return null;
	}
	
	private class AttractionAction implements ActionListener{
		private Attraction attraction ;
		public AttractionAction(Attraction attraction) {
			this.attraction=attraction;
		}
		
		public void actionPerformed(ActionEvent e) {
			attractionChoisi=attraction;
			dispose();
		}
	}

	public class Mouse extends JFrame implements MouseListener {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private JButton b;
		
		Attraction attraction;
        public Mouse(Attraction attraction)
        {
            this.attraction = attraction;
			b = getButton(attraction.getNom());
        }
         
		
		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
			if (attraction.getPrix()>Tirelire.getInstance().getArgent()	|| Niveau.getInstance().getNiveau() < attraction.getLevelRequered()) {
				b.setEnabled(false);
			}
			setLabelText(attraction);
			control.add(lab);
			control.updateUI();
		}
			

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub 
			b.setEnabled(true);
			control.remove(lab);
			control.updateUI();
		}
		
	}
}