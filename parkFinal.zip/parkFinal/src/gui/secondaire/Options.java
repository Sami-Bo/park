package gui.secondaire;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import config.GameConfiguration;
import engine.mobile.Satisfaction;

public class Options extends JFrame {
	
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(800, 400);

	private static final long serialVersionUID = 1L;

	private static Font font = new Font(Font.MONOSPACED, Font.BOLD, 35);
	
	private JLabel optionLabel = new JLabel("Difficult�");
	
	private JButton easyButton = new JButton(" Facile ");
	private JButton mediumButton = new JButton(" Normale ");
	private JButton hardButton = new JButton(" Difficile ");
	
	private JPanel control = new JPanel();
	
	private static Options instance = new Options("Options");

	private Options(String title) {
		super(title);
		init();
	}
	
	private void init() {
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		control.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 40));
		control.setPreferredSize(new Dimension(300,400));
		
		optionLabel.setFont(font);
		control.add(optionLabel);
		
		easyButton.setFont(font);
		easyButton.addActionListener(new EasyAction());
		control.add(easyButton);
		
		mediumButton.setFont(font);
		mediumButton.addActionListener(new MediumAction());
		control.add(mediumButton);
		
		hardButton.setFont(font);
		hardButton.addActionListener(new HardAction());
		control.add(hardButton);
				
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));
		contentPane.add(BorderLayout.NORTH, control);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setPreferredSize(IDEAL_MAIN_DIMENSION);
		setResizable(true);
	}
	
	public static Options getInstance() {
		return instance;
	}
	
	private class EasyAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			Satisfaction.setTaux(75); 
			GameConfiguration.DIFICULTE="facile";
			setVisible(false);
		}
	}
	
	private class MediumAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			Satisfaction.setTaux(50); 
			GameConfiguration.DIFICULTE="normale";
			setVisible(false);
		}
	}
	
	private class HardAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			Satisfaction.setTaux(40); 
			GameConfiguration.DIFICULTE="difficile";
			setVisible(false);
		}
	}
}
