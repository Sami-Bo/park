package gui.secondaire;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import engine.mobile.Employe;
import engine.process.EmployeManager;


public class MenuEmploye extends JFrame {
		
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(800, 400);

	private static final long serialVersionUID = 1L;
	
	private JPanel control = new JPanel();
	
	private JButton recrutementButton = new JButton("Recruter");
				
	//private static MenuEmploye l = new MenuEmploye("employe");//
			
	public MenuEmploye(String title){
		super(title);
		init();
	}

	
	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		control.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 40));
		control.setPreferredSize(new Dimension(500,450));
		
		for(int i=0;i<EmployeManager.getContacts().size();i++) {
			Employe employe = EmployeManager.getContacts().get(i);
			if(employe.hasRole(employe)) {
				JLabel label = new JLabel(employe.getNom()+"  "+employe.getPrenom()+"  Salaire: "+employe.getSalaire()+"$  Efficacite: "+employe.getEfficacite()+"%           Attraction: "+employe.getRole().getNom());
				control.add(label);
			}
			else {
				JLabel label = new JLabel(employe.getNom()+"  "+employe.getPrenom()+"  Salaire: "+employe.getSalaire()+"$  Efficacite: "+employe.getEfficacite()+"%           Pas Encore de R�le");
				control.add(label);
			}
		}
		
		recrutementButton.addActionListener(new RecrutementAction());
		
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));

		contentPane.add(BorderLayout.NORTH, control);
		
		contentPane.add(BorderLayout.SOUTH, recrutementButton);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setPreferredSize(IDEAL_MAIN_DIMENSION);
		setResizable(true);
	}
	
	/*public static MenuEmploye getInstance() {
		return l;
	}*/
	
	private class RecrutementAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			MenuRecrutement menuRecrutement = new MenuRecrutement("Recrutement");
			menuRecrutement.setVisible(true);
			dispose();
		}
		
	}
	
	
}