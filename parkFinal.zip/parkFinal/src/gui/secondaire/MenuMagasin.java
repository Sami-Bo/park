package gui.secondaire;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import config.MagasinConfiguration;
import construction.Magasin;
import engine.mobile.Niveau;
import engine.mobile.Tirelire;

public class MenuMagasin extends JFrame {
	
	private static Magasin MagasinChoisi ;
	
	
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(1000, 600);

	private static final long serialVersionUID = 1L;
	
	private static Font font = new Font(Font.MONOSPACED, Font.BOLD, 30);
	
	private JPanel control = new JPanel();
		
	JButton buttonFastFood = new JButton("FastFood");
	JButton buttonSouvenir = new JButton("BoutiqueSouvenir");
	JButton buttonRestaurant = new JButton("Restaurant de Luxe");
	JButton buttonCinema = new JButton("Cinema");
		
	private JLabel lab = new JLabel();
			
	public MenuMagasin(String title){
		super(title);
		init();
	}
	
	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		control.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 40));
		control.setPreferredSize(new Dimension(400,500));

		buttonFastFood.addActionListener(new MagasinAction(MagasinConfiguration.FastFood));
		buttonFastFood.addMouseListener(new Mouse(MagasinConfiguration.FastFood));
		buttonFastFood.setFont(font);
		control.add(buttonFastFood);
		
		buttonSouvenir.addActionListener(new MagasinAction(MagasinConfiguration.BoutiqueSouvenir));
		buttonSouvenir.addMouseListener(new Mouse(MagasinConfiguration.BoutiqueSouvenir));
		buttonSouvenir.setFont(font);
		control.add(buttonSouvenir);
		
		buttonRestaurant.addActionListener(new MagasinAction(MagasinConfiguration.Restaurant));
		buttonRestaurant.addMouseListener(new Mouse(MagasinConfiguration.Restaurant));
		buttonRestaurant.setFont(font);
		control.add(buttonRestaurant);
		
		buttonCinema.addActionListener(new MagasinAction(MagasinConfiguration.Cinema));
		buttonCinema.addMouseListener(new Mouse(MagasinConfiguration.Cinema));
		buttonCinema.setFont(font);
		control.add(buttonCinema);
		
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));

		contentPane.add(BorderLayout.NORTH, control);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setPreferredSize(IDEAL_MAIN_DIMENSION);
		setResizable(true);
	}
	
	public void setLabelText(Magasin d) {
		lab.setText(" Niveau : " + d.getLevelRequered() + " Prix : " + d.getPrix() +"$ Xp : " + d.getBonusExp());
	}
	
	public static Magasin getMagasinChoisi() {
		return MagasinChoisi;
	}
	
	public static void initMagasinChoisi() {
		MagasinChoisi=null;
	}
	
	private class MagasinAction implements ActionListener{
		private Magasin magasin ;
		public MagasinAction(Magasin magasin) {
			this.magasin=magasin;
		}
		
		public void actionPerformed(ActionEvent e) {
			MagasinChoisi = magasin;
			dispose();
		}
	}
	
	public JButton getButton(String name) {
		if (name.equals("FastFood"))
				return buttonFastFood;
		else if (name.equals("BoutiqueSouvenir"))
				return buttonSouvenir;
		else if (name.equals("Restaurant Luxe"))
			return buttonRestaurant ;
		else if (name.equals("Cinema"))
			return buttonCinema;
		else
			return null;
	}

	public class Mouse extends JFrame implements MouseListener {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private JButton b;
		
		Magasin magasin;
        public Mouse(Magasin magasin)
        {
            this.magasin = magasin;
            b = getButton(magasin.getNom());
        }
         
		
		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
			setLabelText(magasin);
			if (magasin.getPrix()>Tirelire.getInstance().getArgent() || Niveau.getInstance().getNiveau() < magasin.getLevelRequered()) {
				b.setEnabled(false);
			}

			control.add(lab);
			control.updateUI();
		}
			

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			b.setEnabled(true);
			control.remove(lab);
			control.updateUI();
		}
		
	}
}