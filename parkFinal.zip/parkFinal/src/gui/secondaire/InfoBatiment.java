package gui.secondaire;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import construction.Batiment;
import construction.Magasin;
import engine.mobile.Employe;
import engine.process.BatimentManager;
import engine.process.EmployeManager;

public class InfoBatiment extends JFrame {
	
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(600, 700);

	private static final long serialVersionUID = 1L;
	
	private JPanel control = new JPanel();
	private JPanel control2 = new JPanel();
	
	private String infoArticles = "" ;
	
	private Batiment batiment ;
	
	private JButton button;
	
	private BatimentManager batimentManager;
	
	public InfoBatiment(String title, Batiment batiment, BatimentManager batimentManager ) {
		super(title);
		this.batiment=batiment;
		this.batimentManager = batimentManager;
		init();
	}
	
	private void init() {
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		control.setLayout(new GridLayout(8,1));
		control.setPreferredSize(new Dimension(400,500));
		
		JLabel infoLabelName = new JLabel("Nom : "+batiment.getNom()) ;
		JLabel infoLabelPrix = new JLabel("Prix : "+batiment.getPrix());
		JLabel infoLabelLvl = new JLabel("Lvl Requis : "+batiment.getLevelRequered());
		JLabel infoLabelCapaciteMax = new JLabel("Capacit� Max : "+batiment.getCapaciteMax()) ;
		JLabel infoLabelCapaciteATM = new JLabel("Nombre de visiteur actuel : "+batiment.getPnj()) ;
		JLabel inLabelBonusExp = new JLabel("Bonus d'Exp : "+batiment.getBonusExp());
		JLabel infoLabelEmploye = new JLabel("Employ�s : "+batiment.getStringListeEmploye());
		control.add(infoLabelName);
		control.add(infoLabelPrix);
		control.add(infoLabelCapaciteATM);
		control.add(infoLabelCapaciteMax);
		control.add(infoLabelLvl);
		control.add(inLabelBonusExp);
		control.add(infoLabelEmploye);
		
		if(isMagasin(batiment)) {
			JLabel infoLabelArticles = new JLabel("Articles : "+infoArticles);
			control.add(infoLabelArticles);
		}
		
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));

		contentPane.add(BorderLayout.CENTER, control);
		
		for(int i=0;i<EmployeManager.getContacts().size();i++) {
			Employe employe = EmployeManager.getContacts().get(i);
			if(employe.hasRole(employe)==false && (batiment.getEmployeMax())!= batiment.getListeEmploye().size()) {
				button = new JButton(employe.getNom()+"  "+employe.getPrenom()+"  Salaire: "+employe.getSalaire()+"$  Efficacite: "+employe.getEfficacite()+"%");
				button.addActionListener(new AffectationEmployeAction(employe));
				control2.add(button);
			}
			
		}
		

		contentPane.add(BorderLayout.SOUTH, control2);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setSize(IDEAL_MAIN_DIMENSION);
		setResizable(true);
		
	}

	public boolean isMagasin(Batiment batiment) {
		if(batiment.getType().equals("MAGASIN")) {
			Magasin magasin = (Magasin) batiment;
	        infoArticles = magasin.getNomsEtPrixArticles();
			return true;
		}
		return false ;
	}
	
	private class AffectationEmployeAction implements ActionListener {
		private Employe employe;
		
		public AffectationEmployeAction(Employe employe) {
			this.employe=employe;
		}
		
		public void actionPerformed(ActionEvent e) {
			
			String name = batiment.getNom();
			for (Batiment batiment : batimentManager.getBatiments()) {
				if (name.equals(batiment.getNom())) {
					employe.setRole(batiment);
					batiment.addEmploye(employe);
				}
			}
			EmployeManager.setRoleEmploye(employe);
			dispose();			
		}
	}	
}