package gui.secondaire;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import engine.mobile.Employe;
import engine.process.EmployeManager;

public class MenuRecrutement extends JFrame {
	
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(800, 400);

	private static final long serialVersionUID = 1L;
	
	private static Font font = new Font(Font.MONOSPACED, Font.BOLD, 20);
	
	private JPanel control = new JPanel();
	
	private JButton ButtonEmploye1 = new JButton();
	private JButton ButtonEmploye2 = new JButton();
	private JButton ButtonEmploye3 = new JButton();
	
	/*private static MenuRecrutement l = new MenuRecrutement("Recrutement");*/
	
	public MenuRecrutement(String title){
		super(title);
		init();
	}
	
	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		control.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 40));
		control.setPreferredSize(new Dimension(800,450));
		
		try {
			Employe employe1 =  new Employe(Employe.GenerateNom(),Employe.GeneratePrenom(),Employe.GenerateEfficacite());
			ButtonEmploye1.setText(employe1.getNom() + " " + employe1.getPrenom() + " Salaire :" + employe1.getSalaire() + "$ Efficacite :" + employe1.getEfficacite() + "%") ;
			ButtonEmploye1.addActionListener(new ButtonEmployeAction(employe1));
			Employe employe2 =  new Employe(Employe.GenerateNom(),Employe.GeneratePrenom(),Employe.GenerateEfficacite());
			ButtonEmploye2.setText(employe2.getNom() + " " + employe2.getPrenom() + " Salaire :" + employe2.getSalaire() + "$ Efficacite :" + employe2.getEfficacite() + "%") ;
			ButtonEmploye2.addActionListener(new ButtonEmployeAction(employe2));
			Employe employe3 =  new Employe(Employe.GenerateNom(),Employe.GeneratePrenom(),Employe.GenerateEfficacite());
			ButtonEmploye3.setText(employe3.getNom() + " " + employe3.getPrenom() + " Salaire :" + employe3.getSalaire() + "$ Efficacite :" + employe3.getEfficacite() + "%") ;
			ButtonEmploye3.addActionListener(new ButtonEmployeAction(employe3));
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
		
		ButtonEmploye1.setFont(font);
		control.add(ButtonEmploye1);
		
		ButtonEmploye2.setFont(font);
		control.add(ButtonEmploye2);
		
		ButtonEmploye3.setFont(font);
		control.add(ButtonEmploye3);
		
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));

		contentPane.add(BorderLayout.NORTH, control);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setPreferredSize(IDEAL_MAIN_DIMENSION);
		setResizable(true);
	}
	
	/*public static MenuRecrutement getInstance() {
		return l;
	}*/
	
	private class ButtonEmployeAction implements ActionListener {

		private Employe employe;
		public ButtonEmployeAction(Employe employe) {
			this.employe=employe;
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			EmployeManager.add(employe);
			dispose();
		}
		
	}

}