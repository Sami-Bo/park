package gui.secondaire;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Aide extends JFrame {
	
	private static final long serialVersionUID = 1L;
	protected JButton retour = new JButton("Retour");
	protected static Font font = new Font(Font.MONOSPACED, Font.BOLD, 15);
	protected static Font font2 = new Font(Font.MONOSPACED, Font.BOLD, 30);
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(18000, 1000);

	private JPanel control =new JPanel();

	public Aide (String title){
		super(title);
		init();
	
	}

	private void init() {
	
	    Container contentPane = getContentPane();
	    contentPane.setLayout(new BorderLayout());
	    
	    control.setLayout(new GridLayout(9,1));
	    control.setPreferredSize(new Dimension(1800,1000));
	    
	    JLabel conseil1 = new JLabel("Pour augmenter le prix de vos entr�es essay� de placer de nouvelles attractions en cliquant sur le menu Attraction.");
	    conseil1.setFont(font);
	    control.add(conseil1);
	    
	    JLabel conseil2 = new JLabel("Si vous manquez de satisfaction n'h�sitez pas � embaucher des employ�s et les attribu�s � un batiment.");
	    conseil2.setFont(font);
	    control.add(conseil2);
	    
	    JLabel conseil3 = new JLabel("Vous pouvez supprimer un route en cliquant sur celle-ci");
	    conseil3.setFont(font);
	    control.add(conseil3);
	    
	    JLabel conseil4 = new JLabel("V�rifiez vos qu�tes et cliquer dessus pour r�cup�r� la r�compense si vous avez effectu� l'action de compl�tion");
	    conseil4.setFont(font);
	    control.add(conseil4);
	    
	    JLabel conseil5 = new JLabel("Si vous n'arrivez pas � placer un batiment v�rifi� que vous avez assez d'argent et le niveau requis.");
	    conseil5.setFont(font);
	    control.add(conseil5);
	    
	    JLabel conseil6 = new JLabel("Placer un magasin pour gagner de l'argent en vendant des articles !");
	    conseil6.setFont(font);
	    control.add(conseil6);
	    
	    JLabel conseil7 = new JLabel("Cliquer sur un batiment pour afficher les informations de celui-ci");
	    conseil7.setFont(font);
	    control.add(conseil7);
	    
	    JLabel conseil8 = new JLabel("Si un batiment passe en fond noir c'est que celui-ci est surcharg� ! Attention ceci fait diminuer votre satisfaction!");
	    conseil8.setFont(font);
	    control.add(conseil8);
	    
	    retour.setFont(font2);
	    control.add(retour);
	    retour.addActionListener(new QuitAction());
	    
	    contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));
	
	    contentPane.add(BorderLayout.NORTH, control );
	
	    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	    pack();
	    setLocationRelativeTo(null);
	    setVisible(true);
	    setPreferredSize(IDEAL_MAIN_DIMENSION);
	    setResizable(true);
	}
	
	private class QuitAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			dispose();
		}
	}
}
