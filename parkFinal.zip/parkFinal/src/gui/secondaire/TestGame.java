package gui.secondaire;


/**
 * @author Sami
 *
 */
public class TestGame {
		
	public static void main(String[] args) {

		MenuPrincipal menu = MenuPrincipal.getInstance();
	}
}
