package gui.secondaire;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import config.QueteConfiguration;
import engine.mobile.Niveau;
import engine.mobile.Tirelire;
import gui.MenuInformationRessources;

public class MenuQuete extends JFrame {
	
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(800, 400);
	private static final long serialVersionUID = 1L;
	
	private JButton quetetest = new JButton(QueteConfiguration.quetetest.getName()+ "  Description : " + QueteConfiguration.quetetest.getDescription());
	private JButton quetetest1 = new JButton(QueteConfiguration.quetetest1.getName()+ "  Description : " + QueteConfiguration.quetetest1.getDescription());
	private JButton quetetest2 = new JButton(QueteConfiguration.quetetest2.getName()+ "  Description : " + QueteConfiguration.quetetest2.getDescription());
	private JButton quetetest3 = new JButton(QueteConfiguration.quetetest3.getName()+ "  Description : " + QueteConfiguration.quetetest3.getDescription());
	private JButton quetetest4 = new JButton(QueteConfiguration.quetetest4.getName()+ "  Description : " + QueteConfiguration.quetetest4.getDescription());
	private JButton quetetest5 = new JButton(QueteConfiguration.quetetest5.getName()+ "  Description : " + QueteConfiguration.quetetest5.getDescription());
	
	private JPanel control = new JPanel();
	
	private static MenuQuete menuQuete = new MenuQuete("Qu�tes");
			
	private MenuQuete(String title){
		super(title);
		init();
	}

	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		control.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 40));
		control.setPreferredSize(new Dimension(300,400));
		
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));
		
		quetetest.addActionListener(new QueteAction());
		control.add(quetetest);
		quetetest1.addActionListener(new QueteAction());
		control.add(quetetest1);
		quetetest2.addActionListener(new QueteAction());
		control.add(quetetest2);
		quetetest3.addActionListener(new QueteAction());
		control.add(quetetest3);
		quetetest4.addActionListener(new QueteAction());
		control.add(quetetest4);
		quetetest5.addActionListener(new QueteAction());
		control.add(quetetest5);

		contentPane.add(BorderLayout.NORTH, control);

		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setPreferredSize(IDEAL_MAIN_DIMENSION);
		setResizable(true);
	}
	
	public static MenuQuete getInstance() {
		return menuQuete;
	}
	
	private class QueteAction implements ActionListener{

		public void actionPerformed(ActionEvent e) {
			
			if(QueteConfiguration.quetetest.isFinish()) {
				if(QueteConfiguration.quetetest.alreadyRecupere()==false) {
					QueteConfiguration.quetetest.setRecupere();
					Tirelire.getInstance().calculArgent(QueteConfiguration.quetetest.getRecompenseArgent());
					MenuInformationRessources.getInstance().setArgent();
					Niveau.getInstance().xpUp(QueteConfiguration.quetetest.getRecompenseXP());
					quetetest.setText("Qu�te Compl�t�e");
				}
			}
			if(QueteConfiguration.quetetest1.isFinish()) {
				if(QueteConfiguration.quetetest1.alreadyRecupere()==false) {
					QueteConfiguration.quetetest1.setRecupere();
					Tirelire.getInstance().calculArgent(QueteConfiguration.quetetest1.getRecompenseArgent());
					MenuInformationRessources.getInstance().setArgent();
					Niveau.getInstance().xpUp(QueteConfiguration.quetetest1.getRecompenseXP());
					quetetest1.setText("Qu�te Compl�t�e");
				}
			}
			if(QueteConfiguration.quetetest2.isFinish()) {
				if(QueteConfiguration.quetetest2.alreadyRecupere()==false) {
					QueteConfiguration.quetetest2.setRecupere();
					Tirelire.getInstance().calculArgent(QueteConfiguration.quetetest2.getRecompenseArgent());
					MenuInformationRessources.getInstance().setArgent();
					Niveau.getInstance().xpUp(QueteConfiguration.quetetest2.getRecompenseXP());
					quetetest2.setText("Qu�te Compl�t�e");
				}
			}
			if(QueteConfiguration.quetetest3.isFinish()) {
				if(QueteConfiguration.quetetest3.alreadyRecupere()==false) {
					QueteConfiguration.quetetest3.setRecupere();
					Tirelire.getInstance().calculArgent(QueteConfiguration.quetetest3.getRecompenseArgent());
					MenuInformationRessources.getInstance().setArgent();
					Niveau.getInstance().xpUp(QueteConfiguration.quetetest3.getRecompenseXP());
					quetetest3.setText("Qu�te Compl�t�e");
				}
			}
			if(QueteConfiguration.quetetest4.isFinish()) {
				if(QueteConfiguration.quetetest4.alreadyRecupere()==false) {
					QueteConfiguration.quetetest4.setRecupere();
					Tirelire.getInstance().calculArgent(QueteConfiguration.quetetest4.getRecompenseArgent());
					MenuInformationRessources.getInstance().setArgent();
					Niveau.getInstance().xpUp(QueteConfiguration.quetetest4.getRecompenseXP());
					quetetest4.setText("Qu�te Compl�t�e");
				}
			}
			if(QueteConfiguration.quetetest5.isFinish()) {
				if(QueteConfiguration.quetetest5.alreadyRecupere()==false) {
					QueteConfiguration.quetetest5.setRecupere();
					Tirelire.getInstance().calculArgent(QueteConfiguration.quetetest5.getRecompenseArgent());
					MenuInformationRessources.getInstance().setArgent();
					Niveau.getInstance().xpUp(QueteConfiguration.quetetest5.getRecompenseXP());
					quetetest5.setText("Qu�te Compl�t�e");
				}
			}
			control.updateUI();
			//dispose();
		}
	
	}
}