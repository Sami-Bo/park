package gui.secondaire;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import gui.MainGUI;

/**
 * Copyright SEDAMOP - Software Engineering
 * 
 * @author tianxiao.liu@cyu.fr
 *
 */
public class MenuPrincipal extends JFrame {
	
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(800, 400);

	private static final long serialVersionUID = 1L;

	private static Font font = new Font(Font.MONOSPACED, Font.BOLD, 35);
	
	private JLabel menuLabel = new JLabel("Bienvenue !!");
	
	private JButton startButton = new JButton(" Jouer ");
	private JButton optionButton = new JButton(" Options ");

	private JPanel control = new JPanel();
	
	private static MenuPrincipal instance = new MenuPrincipal("Menu Principal");
		
	private MenuPrincipal(String title) {
		super(title);
		init();
	}
	
	private void init() {

		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		control.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 40));
		control.setPreferredSize(new Dimension(300,400));
		
		menuLabel.setFont(font);
		control.add(menuLabel);
		
		startButton.setFont(font);
		startButton.addActionListener(new CommencerAction());
		control.add(startButton);
		
		optionButton.setFont(font);
		optionButton.addActionListener(new OptionAction());
		control.add(optionButton);
		
		
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));
		contentPane.add(BorderLayout.NORTH, control);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setPreferredSize(IDEAL_MAIN_DIMENSION);
		setResizable(true);
	}

	public static MenuPrincipal getInstance() {
		return instance;
	}
	
	private class CommencerAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			Options.getInstance().dispose();
			dispose();
			MainGUI park = new MainGUI("Park")	;
			Thread gameThread = new Thread(park);
			park.setLocation(500,75);
			gameThread.start();
		}
	}
	
	private class OptionAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			Options option = Options.getInstance();
		}
	}
}
