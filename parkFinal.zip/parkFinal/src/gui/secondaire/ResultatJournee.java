package gui.secondaire;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import engine.mobile.Satisfaction;
import engine.mobile.Tirelire;

public class ResultatJournee extends JFrame {
	
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(800, 600);

	private static final long serialVersionUID = 1L;

	private static Font font1 = new Font(Font.MONOSPACED, Font.BOLD, 30);
	private static Font font2 = new Font(Font.MONOSPACED, Font.BOLD, 20);
	
	private JLabel resultatJourneeLabel = new JLabel("R�sultats de la Journ�e");
	
	private JLabel resultatArgentLabel = new JLabel();
	private JLabel resultatSatisfactionLabel =  new JLabel();
	
	private JPanel control = new JPanel();

	public ResultatJournee(String title) {
		super(title);
		init();
	}
	
	private void init() {
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		control.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 40));
		control.setPreferredSize(new Dimension(600,400));
		
		resultatJourneeLabel.setFont(font1);
		control.add(resultatJourneeLabel);
		
		resultatArgentLabel.setFont(font2);
		resultatArgentLabel.setText("Variation Argent : " + Tirelire.getVariationTirelire() + "$");
		Tirelire.restartVariationTirelire();
		control.add(resultatArgentLabel);
		
		resultatSatisfactionLabel.setFont(font2);
		resultatSatisfactionLabel.setText("Variation Satisfaction : " + Satisfaction.getVariationSatisfaction() + "%");
		Satisfaction.restartVariationSatisfaction();
		control.add(resultatSatisfactionLabel);
		
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));
		contentPane.add(BorderLayout.NORTH, control);

		//setDefaultCloseOperation(EXIT_ON_CLOSE);//
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setPreferredSize(IDEAL_MAIN_DIMENSION);
		setResizable(true);
	}
}