package gui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import config.GameConfiguration;
import config.QueteConfiguration;
import construction.Batiment;
import construction.Route;
import engine.map.Block;
import engine.map.Map;
import engine.mobile.Niveau;
import engine.mobile.Satisfaction;
import engine.mobile.Tirelire;
import engine.process.BatimentManager;
import engine.process.GameBuilder;
import engine.process.GameFactory;
import engine.process.MobileElementManager;
import gui.secondaire.InfoBatiment;
import gui.secondaire.MenuAttractions;
import gui.secondaire.MenuDecoration;
import gui.secondaire.MenuMagasin;
import gui.secondaire.MenuQuete;
import gui.secondaire.ResultatJournee;

/**
 * MainGui Class for Park
 * @author Thomas
 * @date 09/02/2022
 */

public class MainGUI extends JFrame implements Runnable {
	
	
	private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(800, 400);
	private final static Dimension preferredSize = new Dimension(GameConfiguration.WINDOW_WIDTH, GameConfiguration.WINDOW_HEIGHT);
	
	/*
	 * Initialisation de la JPanel pour les Menus
	 */
	private BoutonsEnHaut BEH = BoutonsEnHaut.getInstance();
	private JPanel q = new JPanel();
	private JPanel p = new JPanel(new BorderLayout());
	private JButton queteButton = new JButton("Quetes");
	 /*
	  *Terrain quadrille de jeu
	  */
	private Map map;
	private BatimentManager batimentManager;
	private MobileElementManager elementManager;
	private GameDisplay dashboard;
	/*
	 * Boutons pour les quetes et succes
	 */
	private MenuConstructionBatiments menuConstruction;
	
	private MouseControls mouseControls = new MouseControls();
	
	private static final long serialVersionUID = 1L;
				
	public MainGUI(String title) 
	{
		super(title);
		init();
	}
	
	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		map = GameBuilder.buildMap();
		batimentManager = GameBuilder.buildInitBatiment(map);
		elementManager = GameBuilder.buildInitMElementManager(map, batimentManager);
		dashboard = new GameDisplay(map,batimentManager, elementManager);
		
		dashboard.setLayout(new FlowLayout(FlowLayout.CENTER));
		dashboard.addMouseListener(mouseControls);
		dashboard.setPreferredSize(preferredSize);

		contentPane.add(dashboard, BorderLayout.CENTER);
		
		menuConstruction = new MenuConstructionBatiments();
		
		q.add(BEH.getBoiteMenuInfoRessource());
		contentPane.add(BorderLayout.NORTH, q);
		
		queteButton.addActionListener(new QueteAction());
		p.add(queteButton, BorderLayout.WEST);
		p.add(menuConstruction.getBoiteMenuConstru(), BorderLayout.CENTER);
		contentPane.add(BorderLayout.SOUTH, p);
				
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocation(500,95);
		pack();
		setVisible(true);
		setPreferredSize(IDEAL_MAIN_DIMENSION);
		setResizable(false);
	}
	
	public void run() {
        //Compteur pour le Downgrade de satisfaction//
        int compteurSatisfactionDowngrade=0;
        while (true) {
            try {
                Thread.sleep(CalendrierGUI.getChronoSpeed());
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
            try {
                if(CalendrierGUI.getCalendrier().isEndOfTheDay()) {
                    ResultatJournee rj = new ResultatJournee("R�sultat de la journ�e") ;
                    Thread.sleep(GameConfiguration.PAUSE_JOURNEES);
                    rj.dispose();
                }
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }

             elementManager.nextRound();
             dashboard.repaint();
             try {
                 if(compteurSatisfactionDowngrade<100) {
                     compteurSatisfactionDowngrade++;
                 }
                 if(compteurSatisfactionDowngrade==100) {
                     compteurSatisfactionDowngrade=0;
                     Satisfaction.DowngradeSatisfaction();
                     Satisfaction.updateVariationSatisfaction(-1);
                 }
             } catch(IllegalArgumentException e) {
                 System.out.println(e.getMessage()) ;
             }
        }
    }
	
	public BatimentManager getBatimentManager() {
		return batimentManager;
	}
	
	public boolean batimentChoisi() {
		if (MenuAttractions.getAttractionChoisi() != null || MenuMagasin.getMagasinChoisi() != null || MenuDecoration.getDecorationChoisi() != null) {
			return true;
		}
		return false;
	}
	
	public void setMoney(Batiment batiment) {
        Tirelire.getInstance().calculArgent(-batiment.getPrix());
        Tirelire.updateVariationTirelire(-batiment.getPrix());
        MenuInformationRessources.getInstance().setArgent();
        
        Niveau.getInstance().xpUp(batiment.getBonusExp());
	}
	
	//Permet les actions de souris//
	public class MouseControls extends JFrame implements MouseListener {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public void mouseClicked(MouseEvent e) {
            int x = e.getX();
            int y = e.getY();

            Block carrePosition = dashboard.getCarrePosition(x, y);
            if (BatimentManager.isOccupiedBlock(carrePosition)) 
            {
            	List<Batiment> batiments = batimentManager.getBatiments() ;
	            for(Batiment batiment : batiments) {
	                if(carrePosition == batiment.getPosition() && !batiment.equals(elementManager.getPorteSortie()) && !batiment.equals(elementManager.getPorteEntree()) && !batiment.getType().equals("ROUTE")) {
	                    new InfoBatiment("Info "+batiment.getNom(),batiment, batimentManager) ;
	                }
	            }
				Route routeASupprimer = null;
				List<Route> routes = elementManager.getRoutes();
				for (Route route : routes) {
					if (carrePosition == route.getPosition()) {
						routeASupprimer = route;
					}
				}
				routes.remove(routeASupprimer);
				batimentManager.getBatiments().remove(routeASupprimer);
	        }
			else if(menuConstruction.isModeActive()){
				if (batimentChoisi() || menuConstruction.getModeRouteActive()) {
					Batiment batiment;
					int bonusEntree = 0;
					if (menuConstruction.getModeAttractionActive()){
						batiment = MenuAttractions.getAttractionChoisi();
						bonusEntree = MenuAttractions.getAttractionChoisi().getBonusEntree();
					}
		
					else if (menuConstruction.getModeMagasinActive()){
						batiment = MenuMagasin.getMagasinChoisi();
					}
					
					else if (menuConstruction.getModeDecorationActive()) {
						batiment = MenuDecoration.getDecorationChoisi();
					}
					else{
						batiment = GameFactory.createRoad(carrePosition);
					}
					batiment.setBlock(carrePosition);
					if(QueteConfiguration.quetetest.isFinish()==false && batiment.getNom().equals("fontaine")) {
						QueteConfiguration.quetetest.setEtatEffectue();
					}
					if(QueteConfiguration.quetetest1.isFinish()==false && batiment.getType().equals("ATTRACTION")) {
						QueteConfiguration.quetetest1.setEtatEffectue();
					}
					if(QueteConfiguration.quetetest3.isFinish()==false && batiment.getType().equals("MAGASIN")) {
						QueteConfiguration.quetetest3.setEtatEffectue();
					}
					if(QueteConfiguration.quetetest5.isFinish()==false && batiment.getType().equals("ROUTE")) {
						QueteConfiguration.quetetest5.setEtatEffectue();
					}
					if (!batimentManager.estDansLaListeDeBatiment(batiment) && Tirelire.enoughMoney(batiment.getPrix())) {
						batimentManager.addBatiment(batiment);
						setMoney(batiment);
						Tirelire.setPrixEntree(bonusEntree);
					}
				}
				else {
					menuConstruction.setAttractionButton();
					menuConstruction.setMagasinButton();
					menuConstruction.setDecorationButton();
				}
			}
		}
		@Override
		public void mousePressed(MouseEvent e) {	
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {

		}

		@Override
		public void mouseEntered(MouseEvent e) {
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
		
		}
	}
	
	private class QueteAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			MenuQuete menuQuete=MenuQuete.getInstance();
			menuQuete.setVisible(true);
		}
	}

}