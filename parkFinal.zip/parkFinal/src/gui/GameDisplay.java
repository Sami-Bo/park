package gui;


import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import config.AttractionConfiguration;
import config.DecorationConfiguration;
import config.GameConfiguration;
import config.MagasinConfiguration;
import construction.Batiment;
import construction.Puerta;
import construction.Route;
import engine.map.Block;
import engine.map.Map;
import engine.mobile.Pnj;
import engine.process.BatimentManager;
import engine.process.MobileElementManager;
import engine.process.SimulationUtility;

/**
 * Copyright SEDAMOP - Software Engineering
 * 
 * @author tianxiao.liu@cyu.fr
 *
 */
public class GameDisplay extends JPanel {

	private static final long serialVersionUID = 1L;

	private Map map;
	private BatimentManager batimentManager;
	private MobileElementManager elementManager;
	private PaintStrategy paintStrategy = new PaintStrategy();
		
	public GameDisplay(Map map, BatimentManager batimentManager, MobileElementManager elementManager) {
		this.map = map;
		this.batimentManager= batimentManager ;
		this.elementManager = elementManager;
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		paintStrategy.paint(map, g);
		
        Puerta puertaEntree = elementManager.getPorteEntree();
        paintStrategy.paint(puertaEntree, g);
        
        Puerta puertaSortie = elementManager.getPorteSortie();
        paintStrategy.paint(puertaSortie, g);
        
        for (Route route : elementManager.getRoutes()) {
            paintStrategy.paint(route, g);
        }
        
        for  (Batiment b : elementManager.getBatimentsSurcharges()) {
			paintStrategy.paint(g, b);
		}

        printBatiment(g2);
		
		for (Pnj pnjs : elementManager.getVisiteurs()) {
			Block position= pnjs.getPosition();
			g2.drawImage(SimulationUtility.readImage("src/images/pnj_11zon.png"),  position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
			
        }
	}
	
	private void printBatiment(Graphics2D g2) {
		for (Batiment batiment: batimentManager.getBatiments()) {
        	Block position = batiment.getPosition();
        	
        	//Image des attractions
        	if (batiment == AttractionConfiguration.RoallerCoaster) {
        		g2.drawImage(SimulationUtility.readImage("src/images/attraction2.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
        	}
        	if (batiment == AttractionConfiguration.GrandSplash) {
        		g2.drawImage(SimulationUtility.readImage("src/images/fusee.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	        }
        	if (batiment == AttractionConfiguration.GrandeRoue) {
	        	g2.drawImage(SimulationUtility.readImage("src/images/GrandeRoue1.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
        	}	
	        if (batiment == AttractionConfiguration.MaisonEnThe) {
	        	g2.drawImage(SimulationUtility.readImage("src/images/Spkyhouse.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	        }
	        if (batiment == AttractionConfiguration.AutoTamponeuse) {
	        	g2.drawImage(SimulationUtility.readImage("src/images/autotemponeuse.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	        }
	        if (batiment == AttractionConfiguration.GuerreDuCosmos) {
	        	g2.drawImage(SimulationUtility.readImage("src/images/fusee.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	        }
	        if (batiment == AttractionConfiguration.Labyrinthe) {
	        	g2.drawImage(SimulationUtility.readImage("src/images/labyrinthe.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	        }
	        
        	//Image des magasins
	   		if (batiment== MagasinConfiguration.FastFood) {
	   			g2.drawImage(SimulationUtility.readImage("src/images/fastfood.png"),  position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	   		}	
	   		if (batiment== MagasinConfiguration.Restaurant){
	   			g2.drawImage(SimulationUtility.readImage("src/images/magasin.png"),  position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	   		}
	   		if (batiment== MagasinConfiguration.BoutiqueSouvenir){
	   			g2.drawImage(SimulationUtility.readImage("src/images/magasin2.png"),  position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	   		}
	   		if (batiment== MagasinConfiguration.Cinema){
	   			g2.drawImage(SimulationUtility.readImage("src/images/fastfood.png"),  position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	   		}
	        
        	//Image des decorations
	   		if (batiment == DecorationConfiguration.arbre) {
	        		g2.drawImage(SimulationUtility.readImage("src/images/arbre.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	        		
	        }
	   		if (batiment == DecorationConfiguration.fontaine) {
	        	g2.drawImage(SimulationUtility.readImage("src/images/fontaine.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	    		
	        }
	   		if (batiment == DecorationConfiguration.banc) {
	        	g2.drawImage(SimulationUtility.readImage("src/images/banc.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
	    		
	        }
	   		if (batiment == DecorationConfiguration.fleur) {
	        	g2.drawImage(SimulationUtility.readImage("src/images/fleurs.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);

		 	}
	   		if (batiment == DecorationConfiguration.etang) {
	        	g2.drawImage(SimulationUtility.readImage("src/images/etang.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);

	        
			}
	   		if (batiment == DecorationConfiguration.statue) {
				g2.drawImage(SimulationUtility.readImage("src/images/statue.png"),position.getColumn()*GameConfiguration.BLOCK_SIZE, position.getLine()*GameConfiguration.BLOCK_SIZE, GameConfiguration.BLOCK_SIZE,GameConfiguration.BLOCK_SIZE, null);
			}
		}	
	}

	//Permet dans le MainGui de determiner le block correspondant au click//
	public Block getCarrePosition(int x, int y) {
		int line = y / GameConfiguration.BLOCK_SIZE;
		int column = x / GameConfiguration.BLOCK_SIZE;
		return map.getBlock(line, column);
	}
}