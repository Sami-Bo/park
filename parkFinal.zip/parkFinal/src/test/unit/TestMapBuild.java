package test.unit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import config.GameConfiguration;
import construction.Attraction;
import construction.Puerta;
import construction.Route;
import engine.map.Map;
import engine.process.BatimentManager;
import engine.process.GameBuilder;
import engine.process.MobileElementManager;
import gui.GameDisplay;

/**
 * Unit test of Game building. Each building of the built map is verified.
 *
 * @author Tianxiao.Liu@u-cergy.fr
 */

public class TestMapBuild {


	private Map map;
	private BatimentManager batimentManager;
	private MobileElementManager elementManager;
	private GameDisplay dashboard;

	
	@Before
	public void prepareGame() {
		map = GameBuilder.buildMap();
		batimentManager = GameBuilder.buildInitBatiment(map);
		elementManager = GameBuilder.buildInitMElementManager(map, batimentManager);
		dashboard = new GameDisplay(map,batimentManager, elementManager);
	}

	@Test
	public void testGameLevel0() {
		assertNotNull(map);
	}
	
	@Test
	public void testGameLevel1() {
		
		assertNotNull(batimentManager);
		
		assertEquals(GameConfiguration.LINE_COUNT+1, batimentManager.getBatiments().size());
		
		assertTrue(batimentManager.getBatiments().get(0) instanceof Attraction);
		assertTrue(batimentManager.getBatiments().get(1) instanceof Puerta);
		assertTrue(batimentManager.getBatiments().get(2) instanceof Route);
	}
	
	@Test
	public void testGameLevel2() {
		assertNotNull(elementManager);
		assertEquals(0, elementManager.getBatimentsSurcharges().size());
		assertEquals(GameConfiguration.LINE_COUNT-2, elementManager.getRoutes().size());
		assertEquals(0, elementManager.getVisiteurs().size());
	}
	
	@Test
	public void testGameLevel3() {
		assertNotNull(dashboard);
	}
}
