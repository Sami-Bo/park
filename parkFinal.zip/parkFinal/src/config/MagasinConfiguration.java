package config;

import construction.Magasin;
import engine.mobile.Article;

public class MagasinConfiguration {
	
	private static Article[] articlesFastFood = {ArticleConfiguration.Burger , ArticleConfiguration.Soda , ArticleConfiguration.Menu} ;
	public static Magasin FastFood = new Magasin("MAGASIN", null , 500  , 1 , 10 , "FastFood" , 10 , 3 , articlesFastFood );
	
	private static Article[]articlesRestaurant = {ArticleConfiguration.homard , ArticleConfiguration.bavette , ArticleConfiguration.pate};
	public static Magasin Restaurant = new Magasin("MAGASIN", null, 5000 , 3 , 25 , "Restaurant Luxe", 20 , 7 , articlesRestaurant) ;
	
	private static Article[] articlesSouvenir = {ArticleConfiguration.ak47 , ArticleConfiguration.citrouille , ArticleConfiguration.panda} ;
	public static Magasin BoutiqueSouvenir = new Magasin("MAGASIN", null , 1000  , 1 , 10 , "BoutiqueSouvenir" , 15 , 4 , articlesSouvenir );
	
	private static Article[] articlesCinema = {ArticleConfiguration.place , ArticleConfiguration.popcorn , ArticleConfiguration.boisson} ;
	public static Magasin Cinema = new Magasin("MAGASIN", null, 20000, 5 ,40 , "Cinema", 60 , 5 , articlesCinema );

}