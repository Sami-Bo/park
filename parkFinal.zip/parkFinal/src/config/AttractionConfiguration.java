package config;

import construction.Attraction;

public class AttractionConfiguration {
	
	public static final Attraction RoallerCoaster  = new Attraction("ATTRACTION", null, 0, 1, 0, 30, "RoallerCoaster",10,6);
	public static Attraction GrandeRoue   = new Attraction("ATTRACTION", null, 30000, 2, 10, 30, "GrandeRoue",10,4);
	public static Attraction MaisonEnThe   = new Attraction("ATTRACTION", null, 3000, 1, 5, 30, "Maison Hantee",10,4);
	public static Attraction GrandSplash   = new Attraction("ATTRACTION", null, 50000, 3, 20, 30, "Grand Splash",10,5);	
	
	public static Attraction AutoTamponeuse = new Attraction("ATTRACTION", null, 40000 , 3, 12 , 30  , "AutoTamponeuse",10,3 );
	public static Attraction Labyrinthe = new Attraction("ATTRACTION", null, 15000, 2, 8, 30,"Labyrinthe",20,3);
	public static Attraction GuerreDuCosmos = new Attraction("ATTRACTION", null, 80000, 4, 25 , 50,"Guerre du Cosmos", 15, 6 ) ;
	
}