package config;

import engine.mobile.Quete;

public class QueteConfiguration {
	
	public static Quete quetetest = new Quete("Qu�te Test", "Placer 1 fontaine", 100 , 20) ;
	
	public static Quete quetetest1 = new Quete("Qu�te Test", "Placer 1 Attraction", 100 , 20) ;
	
	public static Quete quetetest2 = new Quete("Qu�te Test", "Cumulez 1 journ�e de jeu", 100 , 20) ;
	
	public static Quete quetetest3 = new Quete("Qu�te Test", "Placer 1 magasin", 100 , 20) ;
	
	public static Quete quetetest4 = new Quete("Qu�te Test", "Cumulez 1 mois de jeu", 100 , 20) ;
	
	public static Quete quetetest5 = new Quete("Qu�te Test", "Construisez 1 route", 100 , 20) ;

}
