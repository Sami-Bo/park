package config;

import construction.Decoration;

public class DecorationConfiguration {
	
	public static Decoration arbre = new Decoration("DECORATION", null, 40,1,10,3, "arbre",0);
	
	public static Decoration fontaine = new Decoration("DECORATION", null, 200, 2, 20, 10, "fontaine",0);
	
	public static Decoration banc = new Decoration("DECORATION", null,20,1,5,2,"banc",0);
	
	public static Decoration fleur = new Decoration("DECORATION", null,15,3,5,5,"Parterre Fleurie",0);
	
	public static Decoration etang = new Decoration("DECORATION", null,300,4,25,10,"Etang",0);
	
	public static Decoration statue = new Decoration("DECORATION", null,10000,5,150,30,"Statue",0);
	
}
