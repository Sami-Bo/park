package config;

import engine.mobile.Article;

public class ArticleConfiguration {
	
	//Article FastFood
	public static final Article Burger = new Article(8, 20 , "Burger");
	public static final Article Soda = new Article(5, 30, "Soda");
	public static final Article Menu = new Article(15, 50, "Menu");
	
	//Article Souvenir
	public static final Article citrouille = new Article(10, 15 , "Citrouille");
	public static final Article panda = new Article(5,60, "Panda");
	public static final Article ak47 = new Article(2,80 , "Ak47");
	
	//Article Restaurant
	public static final Article pate = new Article(20, 25 , "P�te au Pesto");
	public static final Article homard = new Article(50,10, "Homard");
	public static final Article bavette = new Article(25,15 , "Bavette");
	
	//Article Cinema
	public static final Article place = new Article(18, 80 , "Place de cin�ma");
	public static final Article popcorn = new Article(5,60, "Pop-Corn");
	public static final Article boisson = new Article(5,40 , "Boisson");
}