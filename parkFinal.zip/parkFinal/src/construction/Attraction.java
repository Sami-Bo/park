package construction;

public class Attraction extends Batiment {

	private int bonusEntree;

	public Attraction(String type, int taille[],float prix, int levelrequered, int bonusEntree, int bonusExp, String nom, int capaciteMax , int nbMaxEmploye) 
	{
		super(type,taille,prix,levelrequered,bonusExp,nom,capaciteMax,nbMaxEmploye);
		this.bonusEntree=bonusEntree;
		
	}
	
	public int getBonusEntree() {
		return bonusEntree;
	}
}