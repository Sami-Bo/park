package construction;

public class Puerta extends Batiment{

	public Puerta(String type, int[] taille, float prix, int levelRequered, int bonusExp, String nom, int capaciteMax) {
		super(type, taille, prix, levelRequered, bonusExp, nom, capaciteMax,0);
		// TODO Auto-generated constructor stub
	}
}