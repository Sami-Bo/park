package construction;

import engine.mobile.Article;

public class Magasin extends Batiment{
	
	private Article[] articles;
	
	public Magasin(String type, int taille[],float prix, int levelrequered, int bonusExp, String nom,int capaciteMax, int nbMaxEmploye, Article[] articles) {
		super(type, taille, prix, levelrequered, bonusExp, nom, capaciteMax , nbMaxEmploye);
		
		this.articles = articles;
	}
	
	public Article[] getArticles() {
		return articles ;
	}
	
	public String getNomsEtPrixArticles() {
		String str="";
		str+=articles[0].getNom()+" : "+articles[0].getPrix()+"$    "+articles[1].getNom()+" : "+articles[1].getPrix()+"$    "+articles[2].getNom()+" : "+articles[2].getPrix()+"$";
		return str;
	}
	
	public Article getArticleCible(int index) {
		return articles[index] ;
	}

}