package construction;

public class Decoration extends Batiment {
	
	private int bonusSatisfaction;

	public Decoration(String type, int taille[],float prix, int levelrequered, /*int bonusEntree,*/ int bonusExp,int bonusSatisfaction, String nom,int capaciteMax) 
	{
		super(type, taille,prix,levelrequered,bonusExp,nom,capaciteMax,0);
		this.bonusSatisfaction=bonusSatisfaction;
	}
	
	public int getBonusSatisfaction() {
		return bonusSatisfaction ;
	}
}