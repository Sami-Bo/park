package construction;



public class Route extends Batiment{
	
	public Route(String type, int taille[],float prix, int levelrequered, int bonusExp, String nom,int capaciteMax) 
	{
		super(type, taille,prix,levelrequered,bonusExp,nom,capaciteMax,0);
	
	
	}

}