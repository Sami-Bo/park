package construction;

import java.util.ArrayList;

import engine.map.Block;
import engine.mobile.Employe;
import engine.mobile.Pnj;

/*
 * @author Dekany, Fernandez, Sami
 */

public abstract class  Batiment {
	private int taille[];
	private Block position;
	private float prix ;
	private int levelRequered ;
	private int bonusExp;
	private int nbMaxEmploye;
	private ArrayList<Employe> listeEmploye = new ArrayList<Employe>();
	private String nom;
	private ArrayList<Pnj> pnjs = new ArrayList<Pnj>();
	private int capaciteMax;
	private String type;
	
	public Batiment(String type, int[]taille ,float prix, int levelRequered, int bonusExp, String nom, int capaciteMax, int nbMaxEmploye){
		this.type = type;
		this.taille = taille;
		this.prix = prix;
		this.levelRequered = levelRequered;
		this.bonusExp = bonusExp;	
		this.nom = nom;
		this.capaciteMax = capaciteMax;
		this.nbMaxEmploye = nbMaxEmploye;
	}
	
	 public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public float getPrix() {
		 return prix;
	 }
	 
	 public int[] getTaille() {
		 return taille;
	 }
	 
	 public int getValeurTaille(int i) {
		 return taille[i];
	 }
	
	 public Block getPosition(){
		 return position;
	 }
	 
	 public void setPosition(Block position) {
		 this.position=position;
	 }
	
	public int getLevelRequered() {
		return levelRequered ;
	}
	
	public int getBonusExp() {
		return bonusExp;
	}
	
	/*public int getBonusEntree() {
		return bonusEntree;
	}*/
	
	public String getNom() {
		return nom;
	}
	
	public int getPnj() {
		return pnjs.size();
	}
	
	public void setBlock(Block block) {
		position=block;
		
	}
	
	public ArrayList<Employe> getListeEmploye(){
		return listeEmploye;
	}
	
	public void addEmploye(Employe employe) {
		if(listeEmploye.size()<=nbMaxEmploye) {
			listeEmploye.add(employe);
		}
	}
	
	public String getStringListeEmploye() {
		String str ="";
		if(listeEmploye!=null) {
			for(int i=0; i<listeEmploye.size();i++) {
				str+=listeEmploye.get(i).getNom()+" "+listeEmploye.get(i).getPrenom()+"   ;   ";
			}
		}
		return str;
	}

	
	public void setCapaciteMax(int capaciteMax) {
		this.capaciteMax = capaciteMax;
	}
	
	public int getCapaciteMax() {
		return capaciteMax;
	}
	
	public void setPnj(Pnj pnj) {
	    pnjs.add(pnj);
	}
	
	public ArrayList<Pnj> getPnjs() {
	    //return pnjs.size();
	    return pnjs;
	}
	
	public int getEmployeMax()
    {
        return nbMaxEmploye;
    }
	
	
}